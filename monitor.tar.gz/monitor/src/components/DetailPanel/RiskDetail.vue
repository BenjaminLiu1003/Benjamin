<template>
  <el-descriptions title="Program Details"
                   direction="vertical"
                   :column="11"
                   size="large"
                   border>
    <el-descriptions-item label="Program"
                          :span="3"
                          :width="255"
                          :content-style="{'text-align': 'center'}"
                          :label-style="{'text-align': 'center'}">
      {{ program.program_name }}
    </el-descriptions-item>
    <el-descriptions-item label="Host"
                          :span="3"
                          :width="255"
                          :content-style="{'text-align': 'center'}"
                          :label-style="{'text-align': 'center'}">
      {{ program.host_name }}
    </el-descriptions-item>
    <el-descriptions-item label="Pid"
                          :width="85"
                          :content-style="{'text-align': 'center'}"
                          :label-style="{'text-align': 'center'}">
      {{ program.pid }}
    </el-descriptions-item>
    <el-descriptions-item label="Reboots"
                          :width="85"
                          :content-style="{'text-align': 'center'}"
                          :label-style="{'text-align': 'center'}">
      <el-tag type="danger">
        {{ program.reboots }}
      </el-tag>
    </el-descriptions-item>
    <el-descriptions-item label="Since"
                          :span="3"
                          :width="255"
                          :content-style="{'text-align': 'center'}"
                          :label-style="{'text-align': 'center'}">
      {{ parseTime(1000 * program.startTime) }}
    </el-descriptions-item>
    <el-descriptions-item label="Symbols"
                          :span="1"
                          :width="85"
                          :content-style="{'text-align': 'center'}"
                          :label-style="{'text-align': 'center'}">
      <el-tag type="success">
        {{ getSymbols(program) }}
      </el-tag>
    </el-descriptions-item>
    <el-descriptions-item label="Engaged"
                          :span="1"
                          :width="85"
                          :content-style="{'text-align': 'center'}"
                          :label-style="{'text-align': 'center'}">
      <el-tag type="success">
        {{ getEngaged(program) }}
      </el-tag>
    </el-descriptions-item>
    <el-descriptions-item label="P&L"
                          :span="1"
                          :width="85"
                          :content-style="{'text-align':'center'}"
                          :label-style="{'text-align':'center'}">
      <el-tag type="success">
        {{ getPNL(program) }}
      </el-tag>
    </el-descriptions-item>
    <el-descriptions-item label="CurrGMV / MaxGMV"
                          :span="8"
                          :content-style="{'text-align': 'center'}"
                          :label-style="{'text-align': 'center'}">
      <el-progress :text-inside="true"
                   :stroke-width="24"
                   :percentage="getGMVPercentage(program)"
                   :format="formatGMV(program)" />
    </el-descriptions-item>
    <!-- <el-descriptions-item :label="formatComponentTitle(program)"
                          :span="10">
      <json-viewer :value="program['modules']"
                   sort
                   copyable></json-viewer>
    </el-descriptions-item> -->
  </el-descriptions>
</template>

<script>
import { parseTime } from "@/utils"
import { getSymbols, getEngaged, getPNL, getGMVPercentage, formatGMV, formatComponentTitle } from "./functions"

export default {
  name: 'RiskDetail',
  props: {
    program: {
      type: Object,
      required: true,
    }
  },
  methods: {
    parseTime,
    getSymbols,
    getEngaged,
    getPNL,
    getGMVPercentage,
    formatGMV,
    formatComponentTitle,
  }
}
</script>
