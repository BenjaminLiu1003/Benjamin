export function getOrders (program) {
  for (var key in program.modules) {
    if (key !== "gwm") {
      continue;
    }
    return program.modules[key].orders;
  }
  return 0;
}

export function getTrades (program) {
  for (var key in program.modules) {
    if (key !== "gwm") {
      continue;
    }
    return program.modules[key].trades;
  }
  return 0;
}
export function getFails (program) {
  for (var key in program.modules) {
    if (key !== "gwm") {
      continue;
    }
    return program.modules[key].fails;
  }
  return 0;
}

export function getSymbols (program) {
  for (var key in program.modules) {
    if (key !== "liqstgy") {
      continue;
    }
    return program.modules[key].symbols;
  }
  return 0;
}

export function getEngaged (program) {
  for (var key in program.modules) {
    if (key !== "liqstgy") {
      continue;
    }
    return program.modules[key].engaged;
  }
  return 0;
}

export function getPNL (program) {
  for (var key in program.modules) {
    if (key !== 'pnl') {
      continue
    }
    return program.modules[key].priority;
  }
  return 0;
}

export function getMaxGMV (program) {
  for (var key in program.modules) {
    if (key !== "liqstgy") {
      continue;
    }
    return program.modules[key].maxGMV;
  }
  return 0;
}

export function getCurrGMV (program) {
  for (var key in program.modules) {
    if (key !== "liqstgy") {
      continue;
    }
    return program.modules[key].currGMV;
  }
  return 0;
}

export function formatGMV (program) {
  return () => {
    return "Curr:" + getCurrGMV(program); // + ",Max:" + maxGMV;
  };
}

export function getGMVPercentage (program) {
  var maxGMV = getMaxGMV(program);
  if (maxGMV == 0) {
    return 0;
  }
  return (getCurrGMV(program) * 100) / maxGMV;
}

export function formatComponentTitle (program) {
  return (
    "All Components Information (updated since " +
    program.updateTime +
    ")"
  )
}