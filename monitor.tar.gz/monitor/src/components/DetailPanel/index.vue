<template>
  <div class="details-container">
    <!-- top-right shortcut buttons: refresh program info, open command console -->
    <el-tooltip effect="dark"
                content="Open Command"
                placement="top-start">
      <i class="el-icon-s-platform"
         style="position:absolute;top:10px;right:10px;cursor:pointer;"
         @click='commandVisible=!commandVisible' />
    </el-tooltip>
    <el-tooltip effect="dark"
                content="Refresh"
                placement="top-start">
      <i class="el-icon-refresh"
         style="position:absolute;top:10px;right:32px;cursor:pointer;"
         @click="refreshProgramInfo" />
    </el-tooltip>

    <!-- command console dialog -->
    <el-dialog width="300"
               title='Command Console'
               :visible.sync='commandVisible'>
      <command-console :selectedPrograms="selectedProgram?[[selectedProgram.project_name, selectedProgram.program_name]]:[]" />
    </el-dialog>

    <!-- different detail page templates for different programs -->
    <component v-if="selectedProgram"
               :is="detailTemplate"
               :program="selectedProgram" />
    <el-descriptions v-else
                     title="Program Details"
                     direction="vertical"
                     :column="1"
                     size="large"
                     border>
      <el-descriptions-item>
        <el-empty :image-size="200"
                  description="Please click a program to select"></el-empty>
      </el-descriptions-item>
    </el-descriptions>

    <component-detail v-if="selectedProgram"
                      :program="selectedProgram" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Message } from 'element-ui'
import AlphaDetail from './AlphaDetail'
import HedgeDetail from './HedgeDetail'
import RiskDetail from './RiskDetail'
import TradingDetail from './TradingDetail'
import ComponentDetail from './ComponentDetail'
import CommandConsole from '@/components/CommandConsole'

export default {
  name: 'DetailPanel',
  components: {
    AlphaDetail,
    HedgeDetail,
    RiskDetail,
    TradingDetail,
    ComponentDetail,
    CommandConsole,
  },
  data () {
    return {
      commandVisible: false
    }
  },
  computed: {
    ...mapGetters([
      'selectedProgram',
    ]),
    detailTemplate () {
      if (this.selectedProgram === null) {
        return ''
      } else if (this.selectedProgram.program_name.indexOf('ALPH') !== -1) {
        return 'AlphaDetail'
      } else if (this.selectedProgram.program_name.indexOf('HEDG') !== -1) {
        return 'HedgeDetail'
      } else if (this.selectedProgram.program_name.indexOf('RISK') !== -1) {
        return 'RiskDetail'
      } else {
        return 'TradingDetail'
      }
    }
  },
  methods: {
    refreshProgramInfo () {
      Message.success('Refresh signal sent!')
    }
  }
}
</script>

<style lang="scss" scoped>
.details-container {
  // max-height: 300px;
  // height: 100%;
  position: relative;
  overflow: auto;
  scrollbar-width: none;
  -ms-overflow-style: none;
  // width: 100%;
  height: calc(100vh - 60px);
  overflow: auto;
  background-color: white;
  padding: 10px;
  border-radius: 5px;
  &::-webkit-scrollbar {
    width: 0 !important;
  }
  &::-webkit-scrollbar {
    width: 0 !important;
    height: 0;
  }
  .scroll-item {
    // height: 200px;
    font-size: 16px;
    margin-bottom: 1px;
    &.info {
      color: var(--info-color);
    }
    &.warn {
      color: var(--warn-color);
    }
    &.error {
      color: var(--error-color);
    }
  }
}
</style>