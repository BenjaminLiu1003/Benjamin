<template>
  <el-table :data="tableData"
            style="width: 100%;"
            row-key="id"
            border
            stripe
            default-expand-all>
    <el-table-column v-for="key in tableHeader"
                     :key="key"
                     :prop="key"
                     :label="key"
                     :fixed="key==='component'"
                     :min-width="key==='component'?160:240">
    </el-table-column>
  </el-table>
</template>

<script>
export default {
  name: 'ComponentDetail',
  props: {
    program: Object,
    required: true,
  },
  data () {
    return {
      tableData: [],
      tableHeader: [],
    }
  },
  watch: {
    'program.modules': {
      deep: true,
      immediate: true,
      handler (val) {
        this.tableData = []
        this.tableHeader = ['component', this.program.program_name]

        var keys = Object.keys(this.program.modules)

        if (this.program.program_name.indexOf('ALPH') === -1) {
          keys.map((item, index) => {
            if (item === 'gwm') {
              keys.unshift(keys.splice(index, 1)[0])
            }
          })
          keys.map((item, index) => {
            if (item === 'pnl') {
              keys.unshift(keys.splice(index, 1)[0])
            }
          })
        }

        for (var key of keys) {
          var data = {
            id: key,
            component: key,
          }

          let program
          if (key === 'startTime') {
            data[this.program.program_name] = this.program.modules[this.program.program_name].startTime
            continue
          }

          data[this.program.program_name] = '-'//JSON.stringify(this.program['modules'][key])

          var children = []
          var sub_keys = Object.keys(this.program.modules[key])

          for (var sub_key of sub_keys) {
            var child = {
              id: key + '-' + sub_key,
              component: sub_key,
            }
            child[this.program.program_name] = this.program.modules[key][sub_key]
            children.push(child)
          }

          data['children'] = children
          this.tableData.push(data)
        }
      }
    }
  }
}
</script>
