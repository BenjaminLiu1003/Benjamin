<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import resize from '@/utils/mixins/resize'
import { mapGetters } from 'vuex'

const animationDuration = 1000 //6000

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '300px'
    },
    plotData: {
      type: Object,
      default: null,
    }
  },
  computed: {
    ...mapGetters([
      'selectedPrograms'
    ])
  },
  data() {
    return {
      chart: null
    }
  },
  watch: {
    plotData: {
      deep: true,
      immediate: true,
      handler (newValue) {
        this.initChart()
      }
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      // let programNames = []
      // let orders = []
      // let trades = []
      // let fails = []
      // for (var program of this.selectedPrograms) {
      //   programNames.push(program.program_name)
      //   orders.push(program['modules']['gwm']['orders'])
      //   trades.push(program['modules']['gwm']['trades'])
      //   fails.push(program['modules']['gwm']['fails'])
      // }
    

      console.log('plotData:', this.plotData)
      if (this.plotData === null || this.plotData.legends.length === 0) {
        return 
      }

      let entries = []
      for (var entry of this.plotData['entries']) {
        entries.push({
          name: entry.name,
          type: 'bar',
          stack: 'vistors',
          barWidth: '60%',
          data: entry.value,
          animationDuration,
        })
      }
      this.chart = echarts.init(this.$el, 'macarons')
      this.chart.setOption({
        tooltip: {
          trigger: 'axis',
          axisPointer: { // 坐标轴指示器，坐标轴触发有效
            type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        grid: {
          top: 10,
          left: '2%',
          right: '2%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: [{
          type: 'category',
          data: this.plotData['legends'], //programNames,// ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          axisTick: {
            alignWithLabel: true
          }
        }],
        yAxis: [{
          type: 'value',
          axisTick: {
            show: false
          }
        }],
        series: entries,
        // [{
        //   name: 'orders', //'pageA',
        //   type: 'bar',
        //   stack: 'vistors',
        //   barWidth: '60%',
        //   data: orders,//[79, 52, 200, 334, 390, 330, 220],
        //   animationDuration
        // }, {
        //   name: 'trades',//'pageB',
        //   type: 'bar',
        //   stack: 'vistors',
        //   barWidth: '60%',
        //   data: trades,//[80, 52, 200, 334, 390, 330, 220],
        //   animationDuration
        // }, {
        //   name: 'fails', //'pageC',
        //   type: 'bar',
        //   stack: 'vistors',
        //   barWidth: '60%',
        //   data: fails,//[30, 52, 200, 334, 390, 330, 220],
        //   animationDuration
        // }]
      })
    }
  }
}
</script>
