<template>
  <div class="command-container">
    <el-form label-position="top"
             label-width="100px"
             style="background-color:white;">
      <el-row :gutter="5">
        <el-col :span="10">
          <el-form-item label="Programs">
            <el-cascader v-model="command.programs"
                         :options="options"
                         :props="{ multiple: true }"
                         collapse-tags
                         clearable
                         @change="changeSelections"
                         style="display:block" />
          </el-form-item>
        </el-col>
        <el-col :span="7">
          <el-form-item label="Components">
            <el-input v-model="command.components" />
          </el-form-item>
        </el-col>
        <el-col :span="7">
          <el-form-item label="Symbols">
            <el-input v-model="command.symbols" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-form-item label="Arguments">
          <el-input v-model="command.arguments" />
        </el-form-item>
      </el-row>
    </el-form>
    <el-tabs type="border-card" style="margin-top:10px;">
      <el-tab-pane v-for="(type, index) in shortcutTypes"
                   :key="index"
                   :label="type">
        <div v-for="(shortcut, index) in shortcuts[type]"
             :key="index"
             style="display:inline-block;margin-bottom:5px;margin-right:5px;">
          <el-button type="primary">
            {{ shortcut }}
          </el-button>
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import { mapGetters } from '_vuex@3.1.0@vuex'
export default {
  name: 'CommandConsole',
  props: {
    selectedPrograms: {
      type: Array,
      required: false,
      default: null
    }
  },
  data () {
    return {
      command: {
        programs: [],
        components: '',
        symbols: '',
        arguments: '',
      },
      shortcutTypes: ['Debug', 'Control', 'Marketdata'],
      shortcuts: {
        Debug: [
          'enable10S',
          'enable1M',
          'enable5M',
          'Status',
        ],
        Control: [
          'engageAll',
          'disengageAll',
          'engageSymbols',
          'disengageSymbols',
        ]
        ,
        Marketdata: [
          'printBooks'
        ]
      }
    }
  },
  computed: {
    ...mapGetters([
      'settings',
    ]),
    options () {
      var options = []
      for (var project of this.settings.allProjects) {
        var option =
        {
          value: project.name,
          label: project.name,
          children: []
        }

        for (var program of this.settings.allPrograms) {
          if (program.project === project.id) {
            option.children.push({
              value: program.name,
              label: program.name
            })
          }
        }
        options.push(option)
      }
      return options
    }
  },
  watch: {
    selectedPrograms: {
      handler: function (val, oldVal) {
        this.command.programs = val
      },
      immediate: true
    },
  },
  methods: {
    changeSelections (value) {
      console.log('change selections:', value)
    }
  }
}
</script>

<style lang="scss" scoped>
.command-container {
  height: 360px;
  padding: 3px 5px 3px 5px;
  background-color: white;
  border-radius: 3px;
  // border: 10px solid white;
}
</style>