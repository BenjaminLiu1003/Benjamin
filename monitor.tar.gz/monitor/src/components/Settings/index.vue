<template>
  <div>
    <svg-icon icon-class="settings"
              @click="click" />
    <el-drawer v-model="showSettings">
      foisdjofishdufh
    </el-drawer>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  name: 'Settings',
  computed: {
    showSettings: {
      get () {
        return this.$store.state.settings.showSettings
      },
      set (value) {
        this.$store.state.settings.showSettings = value
      }
    }
  },
  methods: {
    click () {
      this.showSettings = !this.showSettings
    },
  }
}
</script>

<style scoped>
.screenfull-svg {
  display: inline-block;
  cursor: pointer;
  fill: #5a5e66;
  width: 20px;
  height: 20px;
  vertical-align: 10px;
}
</style>
