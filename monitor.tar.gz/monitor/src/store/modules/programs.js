const state = {
  selectedPrograms: [],
  selectedProgram: null,
}

const mutations = {
  SET_SELECTED_PROGRAMS: (state, selectedPrograms) => {
    state.selectedPrograms = selectedPrograms
  },
  SET_SELECTED_PROGRAM: (state, selectedProgram) => {
    state.selectedProgram = selectedProgram
  }
}

const actions = {
  setSelectedPrograms({ commit }, selectedPrograms) {
    commit('SET_SELECTED_PROGRAMS', selectedPrograms)
  },
  setSelectedProgram({ commit }, selectedProgram) {
    commit('SET_SELECTED_PROGRAM', selectedProgram)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
