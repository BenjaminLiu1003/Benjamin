import variables from '@/styles/element-variables.scss'
import { infoColor, warnColor, errorColor, gridCols, gridHeight, gridFontSize }from '@/styles/variables.scss'
import defaultSettings from '@/settings'
import { getSettings, saveSettings } from '@/api/user'

const { showSettings, tagsView, fixedHeader, sidebarLogo } = defaultSettings

const state = {
  theme: variables.theme,
  settings: {
    grid: {
      cols: gridCols,
      height: gridHeight,
      fontSize: gridFontSize,
      infoColor: infoColor,
      warnColor: warnColor,
      errorColor: errorColor,
    },
    allProjects: [],
    allHosts: [],
    allPrograms: [],
    selectedProjects: [],
    selectedHosts: [],
    singleSelectedProject: null,
    singleSelectedHost: null,
    indeterminateProjects: false,
    indeterminateHosts: false,
    selectAllProjects: false,
    selectAllHosts: false,
  },
  showSettings: showSettings,
  tagsView: tagsView,
  fixedHeader: fixedHeader,
  sidebarLogo: sidebarLogo
}

const mutations = {
  CHANGE_SETTING: (state, { key, value }) => {
    console.log('CHANGE_SETTING:', { key, value })
    // eslint-disable-next-line no-prototype-builtins
    if (state.hasOwnProperty(key)) {
      state[key] = value
    }
  }
}

const actions = {
  getSettings({ commit, state }) {
    return new Promise((resolve, reject) => {
      getSettings(state.token).then(response => {
        const { data } = response
        const { settings } = data
        if (!settings) {
          reject('Verification failed, please Login again.')
        }
        console.log('settings:', settings)
        
        var selectedProjects = []
        var selectedHosts = []
        for (var project of settings.projects) {
          selectedProjects.push(project.name);
        }
        for (var host of settings.hosts) {
          selectedHosts.push(host.name);
        }

        commit('CHANGE_SETTING', {
          key: 'settings',
          value: {
            grid: {
              cols: settings.grid_cols,
              height: settings.grid_height,
              fontSize: settings.grid_font_size,
              infoColor: settings.info_color,
              warnColor: settings.warn_color,
              errorColor: settings.error_color,
            },
            allProjects: data.all_projects,
            allHosts: data.all_hosts,
            allPrograms: data.all_programs,
            selectedProjects: selectedProjects,
            selectedHosts: selectedHosts,
            singleSelectedProject: null,
            singleSelectedHost: null,
            indeterminateProjects: selectedProjects.length > 0 && selectedProjects.length < data.all_projects.length,
            indeterminateHosts: selectedHosts.length > 0 && selectedHosts.length < data.all_hosts.length,
            selectAllProjects: selectedProjects.length === data.all_projects.length,
            selectAllHosts: selectedHosts.length === data.all_hosts.length,
          }
        })
        resolve(data)
      }).catch(error => {
        reject(error)
      })
    })
  },
  changeSetting({ commit }, data) {
    commit('CHANGE_SETTING', data)
  },
  saveSettings({ commit }) {
    return new Promise((resolve, reject) => {
      saveSettings({ info_color: state.settings.grid.infoColor, 
              warn_color: state.settings.grid.warnColor,
              error_color: state.settings.grid.errorColor,
              grid_cols: state.settings.grid.cols,
              grid_height: state.settings.grid.height,
              grid_font_size: state.settings.grid.fontSize,
              hosts: state.settings.selectedHosts,
              projects: state.settings.selectedProjects }).then(response => {
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

