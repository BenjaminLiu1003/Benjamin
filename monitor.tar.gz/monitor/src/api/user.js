import request from '@/utils/request'

export function login(data) {
  return request({
    url: '/account/login',
    method: 'post',
    data
  })
}

export function logout() {
  return request({
    url: '/account/logout',
    method: 'post'
  })
}

export function getInfo(token) {
  return request({
    url: '/info/all',
    method: 'get',
    params: { token }
  })
}

export function getSettings(token) {
  return request({
    url: '/settings/all',
    method: 'get',
    params: { token }
  })
}

export function saveSettings(data) {
  return request({
    url: '/settings/all',
    method: 'post',
    data
  })
}

