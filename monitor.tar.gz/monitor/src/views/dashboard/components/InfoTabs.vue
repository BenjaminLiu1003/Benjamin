<template>
  <el-tabs v-model="currentTab"
           tab-position="right"
           style="height:100%">
    
    <!-- only show logs -->
    <el-tab-pane label="Logs"
                 name="logs">
      <span slot="label">
        <span class="span-box">
          <el-tooltip effect="dark"
                      content="Logs"
                      placement="bottom-start">
            <i class="el-icon-s-comment"></i>
          </el-tooltip>
        </span>
      </span>
      <logs-panel :programs="programs"
                  :logs="logs" />
    </el-tab-pane>

    <!-- logs and command console -->
    <el-tab-pane label="Logs&Command"
                 name="logs_command">
      <span slot="label">
        <span class="span-box">
          <el-tooltip effect="dark"
                      content="Logs&Command"
                      placement="bottom-start">
            <i class="el-icon-s-platform"></i>
          </el-tooltip>
        </span>
      </span>
      <logs-panel :programs="programs"
                  :logs="logs"
                  :bottom="variables.commandHeight" />
      <div class="command-container">
        <command-console />
      </div>
    </el-tab-pane>

    <!-- component comparison panel -->
    <el-tab-pane label="Program Details"
                 name="details"
                 style="padding-top:10px;">
      <span slot="label">
        <span class="span-box">
          <el-tooltip effect="dark"
                      content="Program Details"
                      placement="bottom-start">
            <i class="el-icon-question"></i>
          </el-tooltip>
        </span>
      </span>
      <detail-panel />
    </el-tab-pane>

  </el-tabs>
</template>

<script>
import DetailPanel from '@/components/DetailPanel';
import CommandConsole from '@/components/CommandConsole';
import LogsPanel from './LogsPanel'
import variables from '@/styles/variables.scss'

export default {
  name: "InfoTabs",
  components: {
    DetailPanel,
    CommandConsole,
    LogsPanel,
  },
  props: {
    programs: {
      type: Array,
      required: true,
      default: null,
    },
    logs: {
      type: Array,
      required: true,
      default: null,
    }
  },
  data () {
    return {
      currentTab: 'logs',
    };
  },
  computed: {
    variables () {
      return variables
    },
  },
  watch: {
    '$store.state.programs.selectedProgram': {
      deep: true,
      immediate: true,
      handler (val) {
        if (val) {
          this.currentTab = 'details'
        } else {
          this.currentTab = 'logs'
        }
      }
    },
  },
}
</script>

<style lang="scss" scoped>
@import "@/styles/variables.scss";

.el-tab-pane {
  height: calc(100vh - 50px);
}
.command-container {
  position: absolute;
  width: 100%;
  left: 0;
  bottom: 0px;
  height: $commandHeight;
  border-radius: 4px;
}
</style>