<template>
  <div ref="scroll"
       class="scroll logs-container"
       :style="{bottom:bottom}">
    <div v-for="(log, index) in logs"
         :key="index"
         class="scroll-item"
         :class="log.state"
         :style="cssVar">
      <p style="font-size:15px">
        {{ formatLogTitle(index) }}
      </p>
      <p style="font-size:15px">
        {{ log.text }}
      </p>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'LogsPanel',
  props: {
    bottom: {
      type: String,
      default: '0px'
    },
    programs: {
      type: Array,
      required: true,
      default: null,
    },
    logs: {
      type: Array,
      required: true,
      default: null,
    }
  },
  watch: {
    'logs': 'scrollToBottom',
  },
  computed: {
    ...mapGetters([
      'settings',
    ]),
    cssVar () {
      return {
        "--info-color": this.settings.grid.infoColor,
        "--warn-color": this.settings.grid.warnColor,
        "--error-color": this.settings.grid.errorColor,
        "--grid-height": this.settings.grid.height + "px",
        "--grid-font-size": this.settings.grid.fontSize + "px",
      };
    },
  },
  methods: {
    formatLogTitle (index) {
      for (var program of this.programs) {
        if (this.logs[index].program_id === program.program_id) {
          return '[' + this.logs[index].ctime + ']:' + program.program_name + '@' + program.host_name
        }
      }
    },
    scrollToBottom () {
      this.$nextTick(() => {
        var el = this.$refs.scroll
        el.scrollTo({
          top: el.scrollHeight - el.clientHeight,
          behavior: 'smooth'
        })
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.scroll {
  // max-height: calc(100vh - 50px);
  overflow: auto;
  scrollbar-width: none;
  -ms-overflow-style: none;

  &::-webkit-scrollbar {
    width: 0 !important;
  }
  &::-webkit-scrollbar {
    width: 0 !important;
    height: 0;
  }
  .scroll-item {
    font-size: 16px;
    margin-bottom: 1px;
    &.info {
      color: var(--info-color);
    }
    &.warn {
      color: var(--warn-color);
    }
    &.error {
      color: var(--error-color);
    }
  }
}
.logs-container {
  position: absolute;
  width: 100%;
  left: 0;
  top: 0;
  bottom: 0px;
}
</style>
