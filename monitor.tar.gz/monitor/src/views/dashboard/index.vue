<template>
  <div class="dashboard-container">
    <div style="position:relative">
      <el-container>
        <!-- main area for program states display -->
        <el-main class="scroll">
          <div v-for="(programsForProject, index) in groupedPrograms"
               :key="index">
            <div style="font-size:20px;color:white;margin-top:10px;margin-bottom:10px;">
              {{ index }}
            </div>
            <el-row v-for="row in Math.ceil(programsForProject.length / settings.grid.cols)"
                    :key="row"
                    :gutter="0"
                    :style="{height: settings.grid.height + 'px'}">
              <el-col v-for="col in settings.grid.cols"
                      :key="col"
                      :span="24 / settings.grid.cols">
                <div v-if="(row - 1) * settings.grid.cols + col - 1 < programsForProject.length"
                     :class="programsForProject[(row - 1) * settings.grid.cols + col - 1].state
                   + (programsForProject[(row - 1) * settings.grid.cols + col - 1].program_id == activePgIdx ? ' selected' : '')"
                     class="thumbnail-box content"
                     :style="cssVar"
                     @click="selectProgram(programsForProject[(row - 1) * settings.grid.cols + col - 1])">
                  {{ programsForProject[(row - 1) * settings.grid.cols + col - 1].program_name }}
                </div>
              </el-col>
            </el-row>
          </div>
        </el-main>

        <!-- logs/logs&command/details -->
        <el-aside class="right-container"
                  width="46%"
                  style="line-height:12px;padding:0;">
          <info-tabs :programs="programs"
                     :logs="logs" />
        </el-aside>
      </el-container>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { createWebSocket, parseResponseCode } from '@/utils/request'
import { InfoTabs } from './components'
import CommandConsole from '@/components/CommandConsole'

export default {
  name: "Dashboard",
  components: {
    CommandConsole,
    InfoTabs,
  },
  data () {
    return {
      socket: null,
      socketUrl: "",
      programs: [],
      groupedPrograms: [],
      logs: [],
      activePgIdx: null,
    };
  },
  computed: {
    ...mapGetters([
      'settings',
      'selectedProgram',
    ]),
    cssVar () {
      return {
        "--info-color": this.settings.grid.infoColor,
        "--warn-color": this.settings.grid.warnColor,
        "--error-color": this.settings.grid.errorColor,
        "--grid-height": this.settings.grid.height + "px",
        "--grid-font-size": this.settings.grid.fontSize + "px",
      };
    }
  },
  created () {
    console.log('created dashboard')
    if (this.selectedProgram !== null) {
      this.activePgIdx = this.selectedProgram.program_id
    }
  },
  destroyed () {
    console.log('destroyed dashboard')
    this.socket && this.socket.close()
    this.socket = null
  },
  watch: {
    'settings.selectedProjects': {
      deep: true,
      immediate: true,
      handler (newValue, oldValue) {
        this.getPrograms()
      }
    },
    'settings.selectedHosts': {
      deep: true,
      immediate: true,
      handler (newValue, oldValue) {
        this.getPrograms()
      }
    },
    'settings.singleSelectedProject': {
      immediate: true,
      handler (newValue, oldValue) {
        this.getPrograms()
      }
    },
    'settings.singleSelectedHost': {
      immediate: true,
      handler (newValue, oldValue) {
        this.getPrograms()
      }
    }
  },
  methods: {
    getInterestedQuery () {
      if (this.settings.singleSelectedProject) {
        return JSON.stringify({
          query: {
            projects: [this.settings.singleSelectedProject]
          }
        })
      } else if (this.settings.singleSelectedHost) {
        return JSON.stringify({
          query: {
            hosts: [this.settings.singleSelectedHost]
          }
        })
      } else {
        return JSON.stringify({
          query: {
            projects: this.settings.selectedProjects,
            hosts: this.settings.selectedHosts,
          }
        })
      }
    },
    getPrograms () {
      if (this.socket !== null) {
        if (this.socket.readyState === 1) {
          // socket already connected
          this.socket.send(this.getInterestedQuery())
        }
      } else {
        const _this = this
        this.socketUrl = "ws:" + location.host + process.env.VUE_APP_SOCKET_API;
        this.socket = createWebSocket(this.socketUrl, () => {
          _this.socket.send(_this.getInterestedQuery())
        }, this.parseWebSocketMsg, () => {
          console.log('socket error')
        }, () => { })
      }
    },
    parseWebSocketMsg (response) {
      response = JSON.parse(response.data);
      parseResponseCode(response, () => {
        var data = response.data;
        // first time: get the whole programs
        if (data.programs !== undefined) {
          this.projects = [];
          this.hosts = [];
          this.programs = [];
          this.groupedPrograms = {};
          this.logs = [];

          try {
            for (var log of data.logs) {
              if (log.level === "0") {
                var state = "info";
              }
              else if (log.level === "1") {
                state = "warn";
              }
              else {
                state = "error";
              }
              this.logs.push({
                program_id: log.program,
                text: log.text,
                level: log.level,
                state: state,
                ctime: log.ctime,
              });
            }
          }
          catch (error) {
            console.log("logs:", error);
          }
          this.projects = data.projects;
          this.hosts = data.hosts;
          this.programs = data.programs;

          var groupedPrograms = {}
          for (var program of this.programs) {
            if (program.modules === undefined) {
              program.modules = {};
              program["state"] = "error";
            }
            else {
              program["state"] = "info";
              for (var key in program.modules) {
                if (key === "gwm" && program.modules[key].fails > program.modules[key].trades) {
                  program["state"] = "error";
                }
              }
            }
            program["last_state_time"] = new Date().getTime();

            if (groupedPrograms[program.project_name] === undefined) {
              groupedPrograms[program.project_name] = []
            }
            groupedPrograms[program.project_name].push(program)
          }

          var sortedProjects = Object.keys(groupedPrograms).sort();
          for (var project of sortedProjects) {
            this.groupedPrograms[project] = groupedPrograms[project]
          }
        }
        else {
          program = data.program;
          for (var idx = 0; idx < this.programs.length; ++idx) {
            if (this.programs[idx].program_id === program.program_id) {
              break
            }
          }
          if (idx >= this.programs.length) {
            return;
          }
          var newState = "info";
          var oldState = this.programs[idx]["state"];
          var lastStateTime = this.programs[idx]["last_state_time"];
          this.programs[idx] = { ...program };
          for (key in program.modules) {
            if (key === "gwm" && program.modules[key].fails > program.modules[key].trades) {
              newState = "error";
            }
          }
          var now = new Date();
          if (oldState.indexOf("error") !== -1 && newState === "info") {
            if (now.getTime() - lastStateTime > 30 * 1000) {
              this.programs[idx]["state"] = newState;
            }
            else {
              this.programs[idx]["state"] = oldState;
            }
          }
          else {
            this.programs[idx]["state"] = newState;
          }
          if (oldState.indexOf('selected') !== -1 && this.programs[idx]['state'].indexOf('selected') === -1) {
            this.programs[idx]['state'] = this.programs[idx]['state'] + ' selected'
          }

          this.programs[idx]["last_state_time"] = now.getTime();
          if (program["log"] && Object.keys(program["log"]).length > 0) {
            if (program["log"]["level"] === "0") {
              state = "info";
            }
            else if (program["log"]["level"] === "1") {
              state = "warn";
            }
            else {
              state = "error";
            }
            this.logs.push({
              program_id: program.program_id,
              text: program["log"]["text"],
              level: program["log"]["level"],
              state: state,
              ctime: program["log"]["ctime"],
            });
          }
          if (this.logs.length > 40) {
            this.logs = this.logs.slice(this.logs.length - 40);
          }
        }
      }, () => {
      });
    },
    selectProgram (program) {
      if (this.activePgIdx == program.program_id) {
        this.activePgIdx = null
        this.$store.dispatch('programs/setSelectedProgram', null)
      } else {
        this.activePgIdx = program.program_id
        this.$store.dispatch('programs/setSelectedProgram', program)
      }
    },
  },
}
</script>

<style lang="scss">
.el-submenu__title:hover,
.el-menu-item:hover {
  background-color: rgb(3, 19, 33) !important;
}
.el-menu--horizontal > .el-submenu .el-submenu__title {
  min-width: 80px;
  text-align: center;
}
</style>

<style lang="scss" scoped>
@import "@/styles/variables.scss";

.dashboard-container {
  background-color: transparent;
  max-height: calc(100vh - 50px);
  // padding: 50px 60px 0px;
  .pan-info-roles {
    font-size: 12px;
    font-weight: 700;
    color: #333;
    display: block;
  }
  .info-container {
    position: relative;
    // margin-left: 190px;
    height: 150px;
    line-height: 200px;
    .display_name {
      font-size: 48px;
      line-height: 48px;
      color: #212121;
      position: absolute;
      top: 25px;
    }
  }
}

.thumbnail-box {
  width: 100%;
  border-radius: 5px;

  &.content {
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    text-overflow: ellipsis;
    padding: 10%;
    font-size: var(--grid-font-size);
    height: var(--grid-height);
  }

  &.info {
    background-color: var(--info-color);
  }

  &.warn {
    background-color: var(--warn-color);
  }

  &.error {
    background-color: var(--error-color);
  }
}

.right-container {
  background-color: transparent;
  height: 100vh;
  position: relative;
}

.scroll {
  max-height: calc(100vh - 50px);
  padding-top: 0px;
  overflow: auto;
  scrollbar-width: none;
  -ms-overflow-style: none;
  &::-webkit-scrollbar {
    width: 0 !important;
  }
  &::-webkit-scrollbar {
    width: 0 !important;
    height: 0;
  }
  .scroll-item {
    // height: 200px;
    font-size: 16px;
    margin-bottom: 1px;
    &.info {
      color: var(--info-color);
    }
    &.warn {
      color: var(--warn-color);
    }
    &.error {
      color: var(--error-color);
    }
  }
}

@keyframes animated-border {
  0% {
    box-shadow: 0 0 0 0 rgba(255, 255, 255, 0.8);
  }
  100% {
    box-shadow: 0 0 0 20px rgba(255, 255, 255, 0);
  }
}

.hover {
  outline: 2px solid white;
  outline-offset: -2px;
  animation: animated-border 1.5s infinite;
}

.selected {
  outline: 2px solid white;
  outline-offset: -2px;
}
</style>

