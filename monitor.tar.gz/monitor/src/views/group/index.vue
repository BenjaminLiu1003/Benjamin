<template>
  <el-container class="app-container documentation-container">
    <el-dialog title="New Group"
               :visible.sync="newGroupFormVisible">
      <el-form :inline="true"
               :model="newGroupInfo">
        <el-form-item label="Group Name">
          <el-input v-model="newGroupInfo.group_name" />
        </el-form-item>
        <el-form-item label="Programs">
          <el-cascader v-model="newGroupInfo.programs"
                       :options="options"
                       :props="{ multiple: true }"
                       :show-all-levels="false"
                       collapse-tags
                       clearable />
        </el-form-item>
      </el-form>
      <span slot="footer"
            class="new-group-form-footer">
        <el-button @click="newGroupFormVisible=false">Cancel</el-button>
        <el-button type="primary"
                   @click="saveNewGroup">Confirm</el-button>
      </span>
    </el-dialog>

    <el-dialog width="100"
               title='Command Console'
               :visible.sync='commandVisible'>
      <command-console :selectedPrograms="[['brazil', 'BR_1']]" />
    </el-dialog>

    <el-aside class="groups-container"
              width="400px"
              style="margin-bottom:0px;padding:0px;background-color:transparent;">

      <div style="width:100%;margin-bottom:10px;border:5px solid white;border-radius:5px;display:flex;justify-content:center;background-color:white;">
        <el-button type="text"
                   icon="el-icon-circle-plus"
                   @click="newGroupFormVisible=true">
          Add new group
        </el-button>
      </div>
      <el-container v-for="(group, index) in groups"
                    :key="index"
                    class="box-card"
                    :class="{selected: activeGroupIdx!==index}"
                    style="position:relative;margin-bottom:10px;"
                    @click.native="selectGroup(index)">

        <el-tooltip v-if="activeGroupIdx===index"
                    effect="dark"
                    content="Open Command"
                    placement="top-start">
          <i class="el-icon-s-platform"
             style="position:absolute;top:10px;right:10px;cursor:pointer;"
             @click='commandVisible=!commandVisible' />
        </el-tooltip>
        <el-tooltip v-if="activeGroupIdx===index"
                    effect="dark"
                    content="Show Comparison"
                    placement="top-start">
          <i class="el-icon-s-grid"
             style="position:absolute;top:10px;right:32px;cursor:pointer;"
             @click='showComparison' />
        </el-tooltip>
        <el-tooltip v-if="activeGroupIdx===index"
                    effect="dark"
                    content="Show Plots"
                    placement="top-start">
          <i class="el-icon-s-marketing"
             style="position:absolute;top:10px;right:54px;cursor:pointer;"
             @click='showPlots' />
        </el-tooltip>
        <el-tooltip v-if="activeGroupIdx===index"
                    effect="dark"
                    content="Refresh"
                    placement="top-start">
          <i class="el-icon-refresh"
             style="position:absolute;top:10px;right:76px;cursor:pointer;"
             @click="refreshGroupInfo" />
        </el-tooltip>

        <el-header style="height:16px;">
          <span>{{ group.group_name }}</span>
          <!-- <el-button style="float: right; padding: 3px 0" type="text">Operation button</el-button> -->
        </el-header>
        <el-divider />
        <el-main style="margin-top:-30px;">
          <el-checkbox-group v-model="group.selectedPrograms"
                             @change="changeSelectedPrograms">
            <el-checkbox v-for="program in group.programs"
                         :key="program"
                         :label="program" />
          </el-checkbox-group>
        </el-main>
      </el-container>
    </el-aside>
    <el-main style="padding-top: 0px;">
      <el-carousel ref="carousel"
                   trigger="click"
                   :autoplay="false"
                   style="height:100%;">
        <el-carousel-item class="table-wrapper">
          <el-row :gutter="6">
            <el-col :xs="24"
                    :sm="24"
                    :lg="8">
              <div class="chart-wrapper">
                <div style="display:flex;justify-content: center;align-items: center;">Orders</div>
                <line-chart />
              </div>
            </el-col>
            <el-col :xs="24"
                    :sm="24"
                    :lg="8">
              <div class="chart-wrapper">
                <div style="display:flex;justify-content: center;align-items: center;">Fills</div>
                <line-chart />
              </div>
            </el-col>
            <el-col :xs="24"
                    :sm="24"
                    :lg="8">
              <div class="chart-wrapper">
                <div style="display:flex;justify-content: center;align-items: center;">Fails</div>
                <line-chart />
              </div>
            </el-col>
          </el-row>
          <el-row :gutter="6">
            <el-col :xs="24"
                    :sm="24"
                    :lg="12">
              <div class="chart-wrapper">
                <div style="display:flex;justify-content: center;align-items: center;">GMV Long/Short</div>
                <line-chart />
              </div>
            </el-col>
            <el-col :xs="24"
                    :sm="24"
                    :lg="12">
              <div class="chart-wrapper">
                <div style="display:flex;justify-content: center;align-items: center;">Profit & Loss</div>
                <line-chart />
              </div>
            </el-col>
          </el-row>
        </el-carousel-item>
        <el-carousel-item class="table-wrapper">
          <!-- table title -->
          <h4 style="text-align: center;margin: 0 0 10px 0;font-size:18px;color:white;">Component-Level Comparison</h4>
          <el-table :data="tableData"
                    style="width: 100%;"
                    :max-height="tableMaxHeight"
                    row-key="id"
                    border
                    stripe
                    default-expand-all>
            <el-table-column v-for="key in tableHeader"
                             :key="key"
                             :prop="key"
                             :label="key"
                             :fixed="key==='component'"
                             :min-width="key==='component'?160:240">
            </el-table-column>
          </el-table>
        </el-carousel-item>
      </el-carousel>
    </el-main>
  </el-container>
</template>

<script>
import { mapGetters } from 'vuex'
import { Message } from 'element-ui'
import CommandConsole from '@/components/CommandConsole'
import LineChart from '@/components/LineChart'
import { createWebSocket, parseResponseCode } from '@/utils/request'

export default {
  components: {
    CommandConsole,
    LineChart,
    Message,
  },
  data () {
    return {
      commandVisible: false,
      newGroupFormVisible: false,
      newGroupInfo: { group_name: '', programs: [], selectedPrograms: [] },
      socket: null,
      socketUrl: '',
      programs: [],
      activeGroupIdx: 0,
      gwmPlotData: { legends: [], entries: [] },
      gmvPlotData: { legends: [], entries: [] },
      tableMaxHeight: `${document.documentElement.clientHeight}` - 180,
      groups: [],
      tableHeader: [],
      tableData: [],
    }
  },
  computed: {
    ...mapGetters([
      'selectedPrograms',
      'settings',
    ]),
    options () {
      var options = []
      for (var project of this.settings.allProjects) {
        var option =
        {
          value: project.name,
          label: project.name,
          children: []
        }

        for (var program of this.settings.allPrograms) {
          if (program.project === project.id) {
            option.children.push({
              value: program.name,
              label: program.name
            })
          }
        }
        options.push(option)
      }
      return options
    }
  },
  mounted () {
    const _this = this;
    window.onresize = function listen () {
      _this.tableMaxHeight = `${document.documentElement.clientHeight}` - 180;
    };
  },
  destroyed () {
    this.socket && this.socket.close()
    this.socket = null
  },
  created () {
    const _this = this
    this.groups.push({ group_name: 'RISK', programs: ['JCTRISK_2', 'JCTRISK_3', 'IOCRISK_1'], selectedPrograms: ['JCTRISK_2', 'JCTRISK_3', 'IOCRISK_1'] })
    this.groups.push({ group_name: 'HEDGE', programs: ['JPHEDG_1', 'IOIHEDG_1'], selectedPrograms: ['JPHEDG_1', 'IOIHEDG_1'] })
    this.groups.push({ group_name: 'ALPHA', programs: ['BRALPH_1', 'JPALPH_3', 'USACALPHA_4', 'JPALPH_1'], selectedPrograms: ['BRALPH_1', 'JPALPH_3', 'USACALPHA_4', 'JPALPH_1'] })
    this.groups.push({ group_name: 'IOC', programs: ['IOC_1', 'IOC_2', 'IOC_3', 'IOC_4'], selectedPrograms: ['IOC_1', 'IOC_2', 'IOC_3', 'IOC_4'] })
    this.groups.push({ group_name: 'RMM', programs: ['BRMM_1', 'BRMM_2', 'JCTRMM_1'], selectedPrograms: ['BRMM_1', 'BRMM_2', 'JCTRMM_1'] })

    this.socketUrl = 'ws:' + location.host + process.env.VUE_APP_SOCKET_API;
    this.socket = createWebSocket(this.socketUrl, () => {
      _this.socket.send(JSON.stringify({
        query: {
          programs: _this.groups[_this.activeGroupIdx].selectedPrograms,
        }
      }))
    }, this.parseWebSocketMsg, () => {
      console.log('socket error')
    }, () => { })
  },

  methods: {
    showPlots () {
      this.$refs.carousel.setActiveItem(0)
    },
    showComparison () {
      this.$refs.carousel.setActiveItem(1)
    },
    refreshGroupInfo () {
      Message.success('Refresh command sent!')
    },
    saveNewGroup () {
      if (this.newGroupInfo.group_name === '' || this.newGroupInfo.programs.length === 0) {
        return
      }
      for (var index in this.newGroupInfo.programs) {
        this.newGroupInfo.programs[index] = this.newGroupInfo.programs[index][1]
        this.newGroupInfo.selectedPrograms.push(this.newGroupInfo.programs[index])
      }
      this.groups.push(this.newGroupInfo)
      this.newGroupInfo = { group_name: '', programs: [], selectedPrograms: [] }
      this.newGroupFormVisible = false
    },
    selectGroup (index) {
      this.activeGroupIdx = index
      if (this.socket.readyState === 1) {
        this.socket.send(JSON.stringify({
          query: {
            programs: this.groups[this.activeGroupIdx].selectedPrograms,
          }
        }))
      }
    },
    changeSelectedPrograms (value) {
      if (this.socket.readyState === 1) {
        this.socket.send(JSON.stringify({
          query: {
            programs: this.groups[this.activeGroupIdx].selectedPrograms,
          }
        }))
      }
    },
    updateGWMPlotData () {
      this.gwmPlotData = {
        legends: [],
        entries: [
          {
            name: 'orders',
            value: [],
          },
          {
            name: 'trades',
            value: []
          },
          {
            name: 'fails',
            value: [],
          },
        ]
      }
      for (var program of this.programs) {
        this.gwmPlotData.legends.push(program.program_name)
        this.gwmPlotData.entries[0].value.push(program['modules']['gwm']['orders'])
        this.gwmPlotData.entries[1].value.push(program['modules']['gwm']['trades'])
        this.gwmPlotData.entries[2].value.push(program['modules']['gwm']['fails'])
      }
    },
    updateGMVPlotData () {
      this.gmvPlotData = { legends: [], entries: [] }
      for (var program of this.programs) {
        this.gmvPlotData.legends.push(program.program_name)
        if (program['modules']['liqstgy'] !== undefined) {
          this.gmvPlotData.entries.push({
            value: program['modules']['liqstgy']['currGMV'],
            name: program.program_name,
          })
        } else if (program['modules']['dummytrading'] !== undefined) {
          this.gmvPlotData.entries.push({
            value: program['modules']['dummytrading']['currGMV'],
            name: program.program_name,
          })
        } else {
          this.gmvPlotData.entries.push({
            value: 0, name: program.program_name
          })
        }
      }
    },
    parseWebSocketMsg (response) {
      response = JSON.parse(response.data);
      parseResponseCode(response, () => {
        var data = response.data;
        // first time: get the whole programs
        if (data.programs !== undefined) {
          this.programs = data.programs;
        }
        else {
          program = data.program;
          for (var idx = 0; idx < this.programs.length; ++idx) {
            if (this.programs[idx].program_id === program.program_id) {
              break
            }
          }
          if (idx >= this.programs.length) {
            return;
          }
          this.programs[idx] = program;
        }

        this.updateGWMPlotData()
        this.updateGMVPlotData()


        let keys = []
        this.tableData = []
        this.tableHeader = ['component']

        for (var program of this.programs) {
          var keys1 = Object.keys(program['modules'])
          var index = keys1.indexOf(program.program_name);
          if (index > -1) {
            keys1[index] = "startTime"
          }
          keys = keys.concat(keys1)
          this.tableHeader.push(program.program_name)
        }
        keys = Array.from(new Set(keys))

        for (var key of keys) {
          var data = {
            id: key,
            component: key,
          }

          let program
          if (key === 'startTime') {
            for (program of this.programs) {
              data[program.program_name] = program['modules'][program.program_name]['startTime']
            }
            continue
          }

          for (program of this.programs) {
            data[program.program_name] = '-'//JSON.stringify(program['modules'][key])
          }

          var children = []
          var sub_keys = []
          for (program of this.programs) {
            if (program['modules'][key] !== undefined) {
              sub_keys = sub_keys.concat(Object.keys(program['modules'][key]))
            }
          }
          sub_keys = Array.from(new Set(sub_keys))

          for (var sub_key of sub_keys) {
            var child = {
              id: key + '-' + sub_key,
              component: sub_key,
            }
            for (program of this.programs) {
              if (program['modules'][key] !== undefined) {
                child[program.program_name] = program['modules'][key][sub_key]
              } else {
                child[program.program_name] = ''
              }
            }
            children.push(child)
          }

          data['children'] = children
          this.tableData.push(data)
        }
      }, () => {
      });
    },
  }
}
</script>

<style lang="scss">
.documentation-container {
  height: calc(100vh - 50px);
  // margin: 50px;
  // display: flex;
  // flex-wrap: wrap;
  // justify-content: flex-start;

  .document-btn {
    flex-shrink: 0;
    display: block;
    cursor: pointer;
    background: black;
    color: white;
    height: 60px;
    padding: 0 16px;
    margin: 16px;
    line-height: 60px;
    font-size: 20px;
    text-align: center;
  }
}

.box-card {
  background-color: white;

  &.selected {
    background-color: lightgray;
  }
}

.groups-container {
  &::-webkit-scrollbar {
    width: 0 !important;
    height: 0;
  }
}
.table-wrapper {
  height: calc(100vh - 150px);
  overflow: auto;
}

.chart-wrapper {
  background: #fff;
  padding: 16px 16px 0;
  margin-bottom: 32px;
}

@media (max-width: 1024px) {
  .chart-wrapper {
    padding: 8px;
  }
}

.components-container {
  position: relative;
  height: 100vh;
}

.left-container {
  background-color: #f38181;
  height: 100%;
}

.right-container {
  background-color: #fce38a;
  height: 200px;
}

.top-container {
  background-color: #fce38a;
  width: 100%;
  height: 100%;
}

.bottom-container {
  width: 100%;
  background-color: #95e1d3;
  height: 100%;
}
</style>

