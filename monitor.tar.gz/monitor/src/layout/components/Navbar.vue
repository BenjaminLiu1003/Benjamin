<template>
  <el-menu :default-active="currentSelection"
             mode="horizontal"
             background-color="black"
             text-color="white"
             active-text-color="#1890ff"
             @select="handleSelect"
             class="el-menu-demo navbar">

      <el-menu-item index="overview"
                    style="background-color: rgba(0, 0, 0, 0.1) !important">
        Overview
      </el-menu-item>

      <el-submenu index="project">
        <template #title>Project</template>
        <el-menu-item v-for="(project, index) in settings.allProjects"
                      :key="index"
                      :index="project.name">
          {{ project.name }}
        </el-menu-item>
      </el-submenu>

      <el-submenu index="host">
        <template #title>Host</template>
        <el-menu-item v-for="(host, index) in settings.allHosts"
                      :key="index"
                      :index="host.name">
          {{ host.name }}
        </el-menu-item>
      </el-submenu>

      <el-menu-item index="group"
                    style="background-color: rgba(0, 0, 0, 0.1) !important">
        Group              
      </el-menu-item>

      <div class="right-menu">
        <screenfull id="screenfull"
                    class="right-menu-item hover-effect" />
        <settings id="header-settings"
                  class="right-menu-item hover-effect" />
      </div>
    </el-menu>
</template>

<script>
import { mapGetters } from 'vuex'
import Screenfull from '@/components/Screenfull'
import Settings from '@/components/Settings'

export default {
  name: 'SelectionMenu',
  components: {
    Screenfull,
    Settings,
  },
  data() {
    return {
      'currentSelection': 'overview',
    }
  },
  computed: {
    ...mapGetters([
      'settings',
    ])
  },
  methods: {
    handleSelect (key, keyPath) {
      if (keyPath[0] === 'group') {
        this.$router.push({name: 'Group'})
        return
      } 
      
      if (keyPath[0] === 'overview') {
        this.settings.singleSelectedProject = null
        this.settings.singleSelectedHost = null
      } else if (keyPath[0] === 'project') {
        this.settings.singleSelectedProject = key
        this.settings.singleSelectedHost = null
      } else if (keyPath[0] === 'host') {
        this.settings.singleSelectedProject = null
        this.settings.singleSelectedHost = key
      }
      this.$router.push('/dashboard')
    },
  }
}
</script>

<style lang="scss" scoped>
.navbar {
  height: 50px;
  overflow: hidden;
  position: relative;
  background: transparent;
  box-shadow: 0 1px 4px rgba(0,21,41,.08);

  .hamburger-container {
    line-height: 46px;
    height: 100%;
    float: left;
    cursor: pointer;
    transition: background .3s;
    -webkit-tap-highlight-color:transparent;

    &:hover {
      background: rgba(0, 0, 0, .025)
    }
  }

  .breadcrumb-container {
    float: left;
  }

  .errLog-container {
    display: inline-block;
    vertical-align: top;
  }

  .right-menu {
    float: right;
    // height: 100%;
    line-height: 100%;

    // &:focus {
    //   outline: none;
    // }

    .right-menu-item {
      display: inline-block;
      padding: 0 8px;
      height: 100%;
      line-height: 56px;;
      font-size: 18px;
      color: #5a5e66;
      vertical-align: text-bottom;

      &.hover-effect {
        cursor: pointer;
        transition: background .3s;

        &:hover {
          background: rgba(0, 0, 0, .025)
        }
      }
    }

    .avatar-container {
      margin-right: 30px;

      .avatar-wrapper {
        margin-top: 5px;
        position: relative;

        .user-avatar {
          cursor: pointer;
          width: 40px;
          height: 40px;
          border-radius: 10px;
        }

        .el-icon-caret-bottom {
          cursor: pointer;
          position: absolute;
          right: -20px;
          top: 25px;
          font-size: 12px;
        }
      }
    }
  }
}
</style>
