import datetime, json
from channels.generic.websocket import AsyncWebsocketConsumer
from common.responseinfo import ResponseInfo


class QuoterConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        # self.room_name = self.scope['url_route']['kwargs']['room_name']
        # self.room_group_name = 'chat_%s' % self.room_name

        # self.level = self.scope['query_string']['level'] // unfinished here, need to split b'level=all&key=all'
        # self.key = self.scope['query_string']['key']
        # self.watch_name = self.level + '_' + self.key

        self.level = self.scope['url_route']['kwargs']['level']
        self.key = self.scope['url_route']['kwargs']['key']
        # self.scope['url_route']['kwargs']['watch_name']
        self.watch_name = self.level + '_' + self.key

        # Join room group
        await self.channel_layer.group_add(
            self.watch_name,
            self.channel_name
        )

        await self.accept()

    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.watch_name,
            self.channel_name

        )

    # Receive message from WebSocket
    async def receive(self, text_data):
        print("Consumer received.....")
        # text_data_json = json.loads(text_data)
        # message = text_data_json['msg']

        # Send message to room group
        await self.channel_layer.group_send(
            self.watch_name,
            {
                'type': 'chat_message',
                'message': "fffffffff"
            }
        )

    # Receive message from room group
    async def chat_message(self, event):
        message = event['message']
        print(message)

        quoters = [
            dict(pgInfo=dict(pg="JPRISK_2", host="fpis-kbsiml35", pid=121083),
                 modInfo=dict(name='gwm', orders=0, fails=0,
                              trades=0)),
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JCTRISK_2", 'host': "fpis-kbsiml14", 'pid': 1221},
                'modInfo': {'name': 'JCTRISK_2', 'type': 'PROGRAM', 'startTime': 1652946619}
            },
            {
                'pgInfo': {'pg': "JCTRISK_1", 'host': "fpis-kbsiml14", 'pid': 1200},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3014, 'engaged': 3014}
            },
            {
                'pgInfo': {'pg': 'JCTRMM_1', 'host': 'fpis-kbsiml14', 'pid': 1299},
                'modInfo': {'name': 'rmm', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3117, 'engaged': 3117}
            },
            {
                'pgInfo': {'pg': 'JCT_4', 'host': 'fpis-kbsiml14', 'pid': 1089},
                'modInfo': {'name': 'LGBM_00_5m', 'type': 'LGBM', 'priority': 200}
            },
            {
                'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JCTRISK_2", 'host': "fpis-kbsiml14", 'pid': 1221},
                'modInfo': {'name': 'JCTRISK_2', 'type': 'PROGRAM', 'startTime': 1652946619}
            },
            {
                'pgInfo': {'pg': "JCTRISK_1", 'host': "fpis-kbsiml14", 'pid': 1200},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3014, 'engaged': 3014}
            },
            {
                'pgInfo': {'pg': 'JCTRMM_1', 'host': 'fpis-kbsiml14', 'pid': 1299},
                'modInfo': {'name': 'rmm', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3117, 'engaged': 3117}
            },
            {
                'pgInfo': {'pg': 'JCT_4', 'host': 'fpis-kbsiml14', 'pid': 1089},
                'modInfo': {'name': 'LGBM_00_5m', 'type': 'LGBM', 'priority': 200}
            },
            {
                'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'pgInfo': {'pg': "TEST_abcdefgh", "host": "", "pid": "" },
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            }
        ]

        logs = [
          { "pg": "JPHEDG_1", 'timestamp': datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S.%f"), "msg": "[JPHEDG_1]: Everything is fine.", "level": "success" },
          { "pg": "JPHEDG_2", 'timestamp': datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S.%f"), "msg": "[JPHEDG_2]: Everything is fine.", "level": "success" },
          { "pg": "JPHEDG_3", 'timestamp': datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S.%f"), "msg": "[JPHEDG_3]: Something is wrong.", "level": "warning" },
          { "pg": "JCT_1", 'timestamp': datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S.%f"), "msg": "[JCT_1]: Everything is fine", "level": "success" },
          { "pg": "JCT_2", 'timestamp': datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S.%f"), "msg": "[JCT_2]: Not responding, please reboot.", "level": "alert" },
          { "pg": "JCT_3", 'timestamp': datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S.%f"), "msg": "[JCT_3]: Not responding, please reboot.", "level": "alert" },
          { "pg": "JPAU_1", 'timestamp': datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S.%f"), "msg": "[JPAU_1]: Reboot success.", "level": "success" },
          { "pg": "JPAU_2", 'timestamp': datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S.%f"), "msg": "[JPAU_2]: Bootstraping, please wait.", "level": "warning" }
        ]
        result = dict(ResponseInfo.GeneralGetSuccess.value,
                      data=dict(quoters=quoters, total_num=len(quoters), logs=logs))

        # Send message to WebSocket
        # await self.send(text_data=json.dumps({
        #     'message': message
        # }))

        print("Sending.....")
        await self.send(text_data=json.dumps(result))
