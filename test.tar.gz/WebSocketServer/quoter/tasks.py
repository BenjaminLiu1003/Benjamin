import socket
import struct
import argparse
import time
import signal
import errno
from celery.signals import celeryd_after_setup
from celery import shared_task
from channels.layers import get_channel_layer
from common.responseinfo import ResponseInfo
from asgiref.sync import async_to_sync

global isrunning
isrunning = True

def sigproc(signum, frame):
    global isrunning
    isrunning = False

def decode_packet(pkt):
    sz = len(pkt)
    message = struct.unpack('<%ds'%(sz), pkt)
    return message

class DummySender:
    def __init__(self, ip, port, ttl):
        self.multicast_group = (ip, port)
        self.ttl = ttl
    
    def receive(self):
        pass

    def destroy(self):
        pass

class MSender:
    def __init__(self, ip, port, ttl):
        self.multicast_group = (ip, port)
        self.ttl = ttl
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(1)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        ttl = struct.pack('b', self.ttl)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl)

        print("$$$$$$$$$$$$$$$$$$$$$$$$$")
        import threading
        th = threading.currentThread()
        print("Thread id: %d" % th.ident)
        print("Name: %s" % th.getName())
        self.sock.bind(('', port))
        print("$$$$$$$$$$$$$$$$$$$$$$$$$")

        group = socket.inet_aton(ip)
        mreq = struct.pack('4sL', group, socket.INADDR_ANY)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

    def receive(self):
        try:
            message = self.sock.recvfrom(1400)
            return message
        except socket.timeout:
            return None
        except socket.error as e:
            if e.errno == errno.EINTR:
                return None
            else:
                raise

    def destroy(self):
        self.sock.close()

class CommandSender:
    def __init__(self, ip, port, ttl, dry):
        self.sender = DummySender(ip, port, ttl) if dry else MSender(ip, port, ttl)

    def receive(self):
        res = self.sender.receive()
        return res
        # if res:
        #     print(struct.unpack('<%ds'%(len(res[0])), res[0]))
        #     print(res[1])

    def destroy(self):
        self.sender.destroy()

from socketserver import BaseRequestHandler, ThreadingUDPServer

class TimeHandler(BaseRequestHandler):
    def handle(self):
        print('Got connection from', self.client_address)
        msg, sock = self.request
        print(msg)
        resp = time.ctime()
        sock.sendto(resp.encode(), self.client_address)

@shared_task(ignore_result=True)
def listen():
    time.sleep(3)
    s = CommandSender("239.100.29.0", 65400, 1, False)
    while isrunning:
        msg = s.receive()
        if msg is None:
            time.sleep(0.01)
            continue

        quoters = [
            dict(pgInfo=dict(pg="JPRISK_2", host="fpis-kbsiml35", pid=121083),
                modInfo=dict(name='gwm', orders=0, fails=0, 
                trades=0)),
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JCTRISK_2", 'host': "fpis-kbsiml14", 'pid': 1221},
                'modInfo': {'name': 'JCTRISK_2', 'type': 'PROGRAM', 'startTime': 1652946619}
            },
            {
                'pgInfo': {'pg': "JCTRISK_1", 'host': "fpis-kbsiml14", 'pid': 1200},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3014, 'engaged': 3014}
            },
            {
                'pgInfo': {'pg': 'JCTRMM_1', 'host': 'fpis-kbsiml14', 'pid': 1299},
                'modInfo': {'name': 'rmm', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3117, 'engaged': 3117}
            },
            {
                'pgInfo': {'pg': 'JCT_4', 'host': 'fpis-kbsiml14', 'pid': 1089},
                'modInfo': {'name': 'LGBM_00_5m', 'type': 'LGBM', 'priority': 200}
            },
            {
                'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JCTRISK_2", 'host': "fpis-kbsiml14", 'pid': 1221},
                'modInfo': {'name': 'JCTRISK_2', 'type': 'PROGRAM', 'startTime': 1652946619}
            },
            {
                'pgInfo': {'pg': "JCTRISK_1", 'host': "fpis-kbsiml14", 'pid': 1200},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3014, 'engaged': 3014}
            },
            {
                'pgInfo': {'pg': 'JCTRMM_1', 'host': 'fpis-kbsiml14', 'pid': 1299},
                'modInfo': {'name': 'rmm', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3117, 'engaged': 3117}
            },
            {
                'pgInfo': {'pg': 'JCT_4', 'host': 'fpis-kbsiml14', 'pid': 1089},
                'modInfo': {'name': 'LGBM_00_5m', 'type': 'LGBM', 'priority': 200}
            },
            {
                'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
        ]
        result = dict(ResponseInfo.GeneralGetSuccess.value,
                      data = dict(quoters=quoters, total_num=len(quoters)))
        print(len(quoters))
        # Send message to WebSocket
        # await self.send(text_data=json.dumps({
        #     'message': message
        # })) 
        channel_layer = get_channel_layer()  
        async_to_sync(channel_layer.group_send)("all_all", {
            'type': 'receive',
            'message': 'async_to_sync function'
        })

    print("destroy socket...")
    s.destroy()
    # serv = ThreadingUDPServer(('', 65400), TimeHandler)
    # serv.serve_forever()

# listen()