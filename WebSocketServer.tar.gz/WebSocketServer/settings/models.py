from django.db import models
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from django.utils import timezone
from django.core.exceptions import ObjectDoesNotExist

from account.models import *
from quoter.models import *


class SettingsManager(models.Manager):
    def createSettings(self, user):
        settings = self.model(user=user)
        settings.save(using=self._db)
        return settings

    def get_or_create(self, **kwargs):
        try:
            return self.get(**kwargs)
        except ObjectDoesNotExist:
            return self.model(user=kwargs['user'])


class Settings(models.Model):
    user = models.OneToOneField(JCTUser, on_delete=models.CASCADE)
    projects = models.ManyToManyField(Project)
    hosts = models.ManyToManyField(Host)

    info_color = models.CharField(
        _('informaiton color'), max_length=20, default="red")
    warn_color = models.CharField(
        _('warning color'), max_length=20, default="yellow")
    error_color = models.CharField(
        _('error color'), max_length=20, default="green")
    grid_cols = models.SmallIntegerField(_('grid columns'), default=24)
    grid_height = models.SmallIntegerField(_('grid height'), default=24)
    grid_font_size = models.SmallIntegerField(_('grid font size'), default=6)

    objects = SettingsManager()
    
    def __str__(self):
        return self.user.name + "_settings"
