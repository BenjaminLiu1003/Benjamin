from django.urls import path
from django.views.decorators.csrf import csrf_exempt
from .views import *

urlpatterns = [
    path('all', csrf_exempt(SettingsView.as_view()))
]
