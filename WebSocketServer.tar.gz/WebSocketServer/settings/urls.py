from django.urls import path
from django.views.decorators.csrf import csrf_exempt
from . import views

urlpatterns = [
    path('all', csrf_exempt(views.GetSettings.as_view()))
]
