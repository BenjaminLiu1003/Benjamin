import json
from django.views import View
from django.http import HttpResponse, JsonResponse, StreamingHttpResponse
from django.utils import timezone
from django.utils.encoding import escape_uri_path
from requests import post
from common.responseinfo import ResponseInfo
from .models import *
from .serializer import *
from account.views import Filter

class GetSettings(View):
    def dispatch(self, request, *args, **kwargs):
        user = request.user
        print(user)
        if user.is_anonymous or not user.is_authenticated:
          return JsonResponse(ResponseInfo.UserUnauthenticated.value)

        return super().dispatch(request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        settings = Settings.objects.get_or_create(user=request.user)
        result = dict(ResponseInfo.GeneralGetSuccess.value,
                      data = dict(settings=SettingsSerializer(settings).data))
        return JsonResponse(result)

    def post(self, request, *args, **kwargs):
        try:
            post_data = Filter.dict_filter(
                json.loads(request.body.decode('utf-8')))
        except Exception as e:
            return JsonResponse(ResponseInfo.GeneralInvalidData.value)

        if post_data is None or not isinstance(post_data, dict):
            return JsonResponse(ResponseInfo.GeneralInvalidData.value)

        infoColor = post_data.get('info_color', None)
        warnColor = post_data.get('warn_color', None)
        errorColor = post_data.get('error_color', None)
        hosts = post_data.get('hosts', None)
        projects = post_data.get('projects', None)
        gridCols = post_data.get('grid_cols', None)
        gridHeight = post_data.get('grid_height', None)
        gridFontSize = post_data.get('grid_font_size', None)

        settings = Settings.objects.get_or_create(user=request.user)
        hosts = Host.objects.filter(name__in=hosts)
        projects = Project.objects.filter(name__in=projects)
        settings.hosts.set(hosts)
        settings.projects.set(projects)
        setattr(settings, 'info_color', infoColor)
        setattr(settings, 'warn_color', warnColor)
        setattr(settings, 'error_color', errorColor)
        setattr(settings, 'grid_cols', gridCols)
        setattr(settings, 'grid_height', gridHeight)
        setattr(settings, 'grid_font_size', gridFontSize)
        settings.save()

        return JsonResponse(dict(ResponseInfo.GeneralGetSuccess.value))