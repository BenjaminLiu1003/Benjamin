import json
from django.views import View
from django.http import JsonResponse
from common.responseinfo import ResponseInfo
from .models import *
from .serializer import *
from quoter.models import *
from quoter.serializer import *


class SettingsView(View):
    def dispatch(self, request, *args, **kwargs):
        user = request.user
        if user.is_anonymous or not user.is_authenticated:
            return JsonResponse(ResponseInfo.UserUnauthenticated.value)

        return super().dispatch(request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        settings = Settings.objects.get_or_create(user=request.user)
        result = dict(ResponseInfo.GeneralGetSuccess.value,
                      data=dict(settings=SettingsSerializer(settings).data,
                                all_projects=ProjectSerializer(
                                    list(Project.objects.all()), many=True).data,
                                all_hosts=HostSerializer(
                                    list(Host.objects.all()), many=True).data,
                                all_programs=ProgramSerializer(list(Program.objects.all()), many=True).data))
        return JsonResponse(result)

    def post(self, request, *args, **kwargs):
        try:
            post_data = json.loads(request.body.decode('utf-8'))
        except Exception as e:
            return JsonResponse(ResponseInfo.GeneralInvalidData.value)

        post_data['projects'] = Project.objects.filter(
            name__in=post_data.get('projects', []))
        post_data['hosts'] = Host.objects.filter(
            name__in=post_data.get('hosts', []))
        settings = Settings.objects.get_or_create(user=request.user)
        settings.update(post_data)

        return JsonResponse(dict(ResponseInfo.GeneralGetSuccess.value))
