from enum import Enum, unique

@unique
class ResponseInfo(Enum):
    # General Response
    GeneralInvalidData = {"code": 400000, "msg": "fail", "desc": "Get invalid data"}
    GeneralGetSuccess = {"code": 200000, "msg": "succ", "desc": "Get request succeeded"}
    GeneralGetFailed = {"code": 400002, "msg": "fail", "desc": "Get request failed" }
    
    # Account Response
    UserUnauthenticated = {"code": 400100, "msg": "fail", "desc": "User authenticated"}
    UserLoginSuccess = {"code": 200104, "msg": "succ", "desc": "User login success"}
    UserLoginFailed = {"code": 400104, "msg": "fail", "desc": "User login failed"}
    UserLogoutSuccess = {"code": 200106, "msg": "succ", "desc": "User logout success"}
    UserLogoutFailed = {"code": 400106, "msg": "fail", "desc": "User logout faield"}
    UserNameUsed = {"code": 400112, "msg": "fail", "desc": "User name used"}
    UserNameSame = {"code": 200124, "msg": "succ", "desc": "User name is the same as the old one"}
    UserNameNew = {"code": 200126, "msg": "succ", "desc": "User name is new"}

    # Settings Response
    SettingsSaved = {"code": 200200, "msg": "succ", "desc": "Settings saved"}
    SettingsRejected = {"code": 400200, "msg": "succ", "desc": "Invalid settings"}