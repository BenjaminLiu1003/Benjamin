from enum import Enum, unique

@unique
class ResponseInfo(Enum):
    # General Response
    GeneralInvalidData = {"code": 400000, "msg": "fail", "desc": "Get invalid data"}
    GeneralGetSuccess = {"code": 200000, "msg": "succ", "desc": "Get request succeeded"}
    GeneralGetFailed = {"code": 400002, "msg": "fail", "desc": "Get request failed" }