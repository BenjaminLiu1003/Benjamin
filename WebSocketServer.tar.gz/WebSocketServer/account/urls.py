from django.conf.urls import include
from django.urls import path
from account import views
from django.views.decorators.csrf import csrf_exempt

app_name = "account"

validators = [
  path('name', csrf_exempt(views.UserNameCheck.as_view())),
]

urlpatterns = [
  path('login', csrf_exempt(views.UserLogin.as_view())),
  path('logout', views.UserLogout.as_view()),
  path('validator/', include(validators)),
  # path('users/(?P<user_id>[0-9]+)$', csrf_exempt(views.UserInfo.as_view())),
]