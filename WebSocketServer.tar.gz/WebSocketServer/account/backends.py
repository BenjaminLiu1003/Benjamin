import hashlib
from .models import JCTUser

class JCTAccountBackend(object):
  def authenticate(self, request, name=None, password=None, **credentials):
    try:
      user = JCTUser.objects.get_or_none(name=name, **credentials)
      if user and user.check_password(password):
        return user
    except Exception as e:
      print(e)
      return None
    
    return None

  def get_user(self, userId):
    try:
      return JCTUser.objects.get_or_none(id=userId)
    except Exception as e:
      print(e)
      return None