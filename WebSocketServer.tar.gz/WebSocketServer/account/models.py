from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from django.core.exceptions import ObjectDoesNotExist
from .hashers import JCTMD5PasswordHasher
from django.db.models import Sum


class JCTUserLogManager(models.Manager):
  def create_user_log(self, user):
    log = self.model(log_start_time=timezone.now(), log_last_active_time=timezone.now(), user=user)
    log.save()
    return log
  
  def get_or_none(self, **kwargs):
    try:
      return self.get(**kwargs)
    except ObjectDoesNotExist:
      return None

class JCTUserManager(BaseUserManager):
    def createUser(self, name, password):
        user = self.model(name=name)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def get_or_none(self, **kwargs):
      try:
        return self.get(**kwargs)
      except ObjectDoesNotExist:
        return None

class JCTUser(AbstractBaseUser):
    name = models.CharField(_('name'), max_length=128, unique=True)

    objects = JCTUserManager()

    USERNAME_FIELD = 'name'

    def check_password(self, raw_password: str) -> bool:
        return JCTMD5PasswordHasher().verify(self.name.upper() + raw_password,
                                             self.password)
        # return super().check_password(raw_password)

    def set_password(self, raw_password) -> None:
        return super().set_password(self.name.upper() + raw_password)

    def update(self, info):
      for key, value in info.items():
        if hasattr(self, key) and value is not None:
          if key == "password":
            self.set_password(value)
      self.save()
      return True

    def __str__(self) -> str:
        return self.name

class JCTUserLog(models.Model):
  id = models.BigAutoField(_('id'), primary_key=True)
  user = models.ForeignKey(JCTUser, on_delete=models.CASCADE, verbose_name=_('user'))
  log_start_time = models.DateTimeField(_('log start date time'), default=timezone.now)
  log_last_active_time = models.DateTimeField(_('log last active date time'), default=timezone.now)
  log_stop_time = models.DateTimeField(_('log stop date time'), blank=True, null=True)
  
  objects = JCTUserLogManager()
  
  def __str__(self):
    return str(self.id)
