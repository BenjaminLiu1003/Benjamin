from django.contrib.auth.hashers import BasePasswordHasher
import hashlib
from collections import OrderedDict
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.hashers import mask_hash


class JCTMD5PasswordHasher(BasePasswordHasher):
    algorithm = "jct_md5"

    def encode(self, password, salt):
        assert password is not None
        assert isinstance(password, str)

        encoded = password.encode("utf-8")

        jctMD5 = hashlib.md5()
        jctMD5.update(encoded)
        return jctMD5.hexdigest()

    def verify(self, password: str, encoded: str) -> bool:
        encoded2 = self.encode(password, "")
        return encoded == encoded2
        # return super().verify(password, encoded)

    def safe_summary(self, encoded: str):
        algorithm = self.algorithm
        return OrderedDict([
            (_('algorithm'), algorithm),
            (-('salt'), ''),
            (_('hash'), mask_hash(encoded)),
        ])
        # return super().safe_summary(encoded)
