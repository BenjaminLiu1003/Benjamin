import calendar
import datetime
import hashlib
import json
import logging
import os
import re
from telnetlib import LOGOUT
import time
from decimal import Decimal
from urllib import response
import django.core.handlers
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.db import transaction
from django.db.models import Sum

from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import redirect
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.utils.encoding import escape_uri_path
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from requests import Response
from .models import *
from common.responseinfo import ResponseInfo
from WebSocketServer import settings

logger = logging.getLogger(__name__)


class TypeCheck:
    @staticmethod
    def validate(value):
        return isinstance(value, int) or (isinstance(value, str) and value is not "") or isinstance(value, bool) or isinstance(value, list) or isinstance(value, datetime) or isinstance(value, date)


class Filter:
    @staticmethod
    def dict_filter(dict_in):
        result = {}
        for key, value in dict_in.items():
            if TypeCheck.validate(value):
                result[key] = value
        return result


class UserLogin(View):
    def post(self, request):
        try:
            post_data = Filter.dict_filter(
                json.loads(request.body.decode('utf-8')))
        except Exception as e:
            return JsonResponse(ResponseInfo.GeneralInvalidData.value)

        if post_data is None or not isinstance(post_data, dict):
            return JsonResponse(ResponseInfo.GeneralInvalidData.value)

        username = post_data.get('username', None)
        password = post_data.get('password', None)
        if username is None or password is None:
            return JsonResponse(ResponseInfo.GeneralInvalidData.value)

        user = authenticate(request, name=username, password=password)
        if user:
            login(request, user)

            log = JCTUserLog.objects.create_user_log(user=user)
            log_expired_datetime = timezone.now() + datetime.timedelta(days=6,
                                                                       hours=23, minutes=59, seconds=59)
            
            logid_cookie_domain = settings.LOGID_COOKIE_DOMAIN

            response_data = dict(ResponseInfo.UserLoginSuccess.value,
                                 data=dict(userid=user.id, name=user.name))
            response = JsonResponse(response_data)
            response.set_cookie("logid", log.id, max_age=604800,
                                expires=log_expired_datetime, domain=logid_cookie_domain)
        else:
            response = JsonResponse(ResponseInfo.UserLoginFailed.value)

        return response


@method_decorator(csrf_exempt, name="dispatch")
class UserLogout(View):
    def dispatch(self, request, *args, **kwargs):
        user = request.user
        if user.is_anonymous or not user.is_authenticated():
            return JsonResponse(ResponseInfo.UserUnauthenticated.value)
        return super().dispatch(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        user = request.user
        try:
            post_data = {}
            body = request.body.decode("utf-8")
            if body is not None and body != "":
                post_data = Filter.dict_filter(json.load(body))
        except Exception as e:
            return JsonResponse(ResponseInfo.GeneralInvalidData.value)

        if 'logid' in request.COOKIES:
            logid = request.COOKIES['logid']
            log = JCTUserLog.objects.get_or_none(
                user_id=user.id, id=int(logid))
            if log is None:
                return JsonResponse(ResponseInfo.GeneralInvalidData.value)
            log.log_stop_time = timezone.now()
            log.save()

        logout(request)
        return JsonResponse(ResponseInfo.UserLogoutSuccess.value)


class UserInfo(View):
    def dispatch(self, request, *args, **kwargs):
        user = request.user
        if user.is_anonymous() or not user.is_authenticated():
            return JsonResponse(ResponseInfo.UserUnauthenticated.value)

        user_id = kwargs.get("user_id", None)
        if user_id is None:
            return JsonResponse(ResponseInfo.GeneralInvalidData.value)

        target_user = JCTUser.objects.get_or_none(id=user_id)
        if target_user is None:
            return JsonResponse(ResponseInfo.GeneralInvalidData.value)

        kwargs["target_user"] = target_user
        return super().dispatch(request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        target_user = kwargs.get("target_user")

        response_data = dict(ResponseInfo.GeneralGetSuccess.value,
                             data=dict(id=target_user.id, name=target_user.name))
        return JsonResponse(response_data)


class UserNameCheck(View):
    def dispatch(self, request, *args, **kwargs):
        user = request.user
        if user.is_anonymous() or not user.is_authenticated():
            return JsonResponse(ResponseInfo.UserUnauthenticated.value)
        return super().dispatch(request, *args, **kwargs)

    def post(self, request):
        user = request.user

        try:
            post_data = Filter.dict_filter(
                json.loads(request.body.decode('utf-8')))
        except Exception as e:
            return JsonResponse(ResponseInfo.GeneralInvalidData.value)

        if post_data is None or not isinstance(post_data, dict):
            return JsonResponse(ResponseInfo.GeneralInvalidData.value)

        name = post_data.get("name", None)
        target_name = post_data.get("target_name", None)

        if name is None:
            return JsonResponse(ResponseInfo.GeneralInvalidData.value)

        if target_name is None:
            if JCTUser.objects.get_or_none(name=name) is not None:
                return JsonResponse(ResponseInfo.UserNameUsed.value)

            return JsonResponse(ResponseInfo.UserNameNew.value)
        else:
            target_user = JCTUser.objects.get_or_none(name=target_name)
            if target_user is None:
                return JsonResponse(ResponseInfo.GeneralInvalidData.value)
            if JCTUser.objects.get_or_none(name=name) is None:
                return JsonResponse(ResponseInfo.UserNameNew.vlaue)
            if name == target_name:
                return JsonResponse(ResponseInfo.UserNameSame.value)
            return JsonResponse(ResponseInfo.UserNameUsed.value)
