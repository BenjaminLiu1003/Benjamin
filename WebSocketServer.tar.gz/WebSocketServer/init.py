import django, os, sqlite3
from random import choice, randint

# os.environ.setdefault("DJANGO_SETTINGS_MODULE", "WebSocketServer.settings")

format_prefix = '\033[1;33m'
format_suffix = '\033[0m'

groups = ['JCT', 'JPAU', 'JPHEDG', 'JTRISK']
hosts = ['fpis_kbsiml14', 'fpis_kbsiml35', 'fpis_kbsiml66']

# cx = sqlite3.connect('./db.sqlite3')
# cursor = cx.cursor()

# cursor.execute("insert into quoter_group values(1, 'JCT')")
# cursor.execute("insert into quoter_group values(2, 'JPAU')")
# cursor.execute("insert into quoter_group values(3, 'JPHEDG')")
# cursor.execute("insert into quoter_group values(4, 'JTRISK')")

# entry_index = 1
# for group in groups:
#   total_programs = randint(10, 20)
#   for i in range(total_programs):
#     name = group + '_' + str(i + 1)
#     host = choice(hosts)
#     pid = randint(6666, 8888)
#     cursor.execute("insert into quoter_program values(" + str(entry_index) + ",'" + name + "', '" + host + "', " + str(pid) + ")")
#     entry_index += 1

# cx.commit()

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "WebSocketServer.settings")
django.setup()
from quoter.models import *

for host in hosts:
  host = Host.objects.addHost(host)

for group_name in groups:
  group = Group.objects.addGroup(group_name)
  total_programs = randint(10, 20)
  for i in range(total_programs):
    name = group_name + '_' + str(i + 1)
    host = choice(hosts)
    pid = randint(6666, 8888)
    Program.objects.addProgram(group=group, name=name, host=host, pid=pid)

programs = []
for program in list(Program.objects.all().values('name')):
  programs.append(program['name'])

for i in range(1000):
  program = choice(programs)
  orders = randint(0, 1000)
  trades = randint(0, orders)
  fails = orders - trades
  maxGMV = randint(10000000, 10000000)
  currGMV = randint(0, maxGMV)
  symbols = randint(0, 1000)
  engaged = randint(0, symbols)
  component1 = Component1.objects.addComponent1(program=program, orders=orders, trades=trades, fails=fails)
  component2 = Component2.objects.addComponent2(program=program, currGMV=currGMV, maxGMV=maxGMV)
  components = Component3.objects.addComponent3(program=program, symbols=symbols, engaged=engaged)