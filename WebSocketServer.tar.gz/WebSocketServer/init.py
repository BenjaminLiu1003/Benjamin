import django
import os
from random import choice, randint

format_prefix = '\033[1;33m'
format_suffix = '\033[0m'

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "WebSocketServer.settings")
django.setup()
from account.models import *
from quoter.models import *
from settings.models import *

JCTUser.objects.createUser("bliu", "123456")
JCTUser.objects.createUser("lliu", "123456")
Settings.objects.createSettings(JCTUser.objects.get(name="jct"))


projects = ["brazil", "japan", "preopen", "useqau", "useqct"]
hosts = ["spa_kbl22", "jpxa_kbl33", "njc_kbl187",
         "njc_kbl190", "fpis_jctsiml1111"]
programs = [["BR_1", "BRALPH_1", "BRHEDG_1", "BRHEDG_2", "BRLQ_1", "BRMM_1", "BRMM_2", "BRRISK_1"],
            ["JP_3", "JP_4", "JPADRLIQ_1", "JPALPH_1", "JPALPH_2", "JPALPH_3", "JPALPH_4",
             "JPAU_1", "JPAU_2", "JPAU_3", "JPAU_4", "JPALAU_1", "JPALAU_2", "JPALAU_3", "JPALAU_4",
             "JPHEDG_1", "JPHEDG_2", "JPLQ_1", "JPLQ_2", "JPLQ_3", "JPLQ_4",
             "JPRISK_1", "JPRISK_2", "JPRISK_3"],
            ["JCT_1", "JCT_2", "JCT_3", "JCT_4", "JCT_5", "JCT_6", "JCT_7", "JCT_8",
             "JPADR_1", "JPADR_2", "JPADRHEDG_1", "JCTALPH_1",
             "JCTHEDG_1", "JCTHEDG_2", "JCTHEDG_4", "JCTRISK_1", "JCTRISK_2", "JCTRISK_3", "JCTRISK_4",
             "JCTRMM_1", "PMAN"],
            ["USACALPHA_1", "USACALPHA_2", "USACALPHA_3", "USACALPHA_4", "USACALPHA_5", "USACALPHA_6",
             "USACHEDG_1", "USACRISK_1", "USACRISK_2", "USACTRADE_1"],
            ["IOC_1", "IOC_2", "IOC_3", "IOC_4", "IOI_1",
                "IOIHEDG_1", "IOIRISK_1", "IOCRISK_1"]
            ]

num = randint(0, 4)
project = projects[num]
host = hosts[num]
program = choice(programs[num])


for host in hosts:
    host = Host.objects.addHost(host)

num = 0
for project in projects:
    project = Project.objects.addProject(project)
    print("Creating: ", project)
    for program in programs[num]:
        print("--->", program)
        host = hosts[num]
        pid = randint(6666, 8888)
        Program.objects.addProgram(name=program, project=project, host=host, pid=pid)
    num += 1
