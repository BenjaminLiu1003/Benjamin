from random import choice, randint, random
from .models import *
from .serializer import *
import json
import time


def mockPROGRAM():
    return {
        # 'type': "PROGRAM",
        'startTime': randint(1653500000, 1653550000)
    }


def mockGWM():
    orders = randint(500, 1000)
    trades = randint(0, orders)
    fails = orders - trades
    return {
        'name': 'gwm',
        'orders': orders,
        'trades': trades,
        'fails': fails,
        'priority': 10,
    }


def mockRISK():
    return {'name': 'risk', 'priority': randint(30, 50)}


def mockRMMSTATUS():
    return {'name': "rmmst", 'priority': randint(500, 600)}


def mockPECM():
    return {'name': "pecm", 'priority': randint(900, 1000)}


def mockPEALPHA():
    return {'name': "preoo", 'priority': randint(500, 600)}


def mockLGBM():
    names = ["LGBM_OO_0900", "LGBM_OO_VWAP", "LGBM_OO_Flow", "LGBM_OO_5m"]
    return {'name': choice(names), 'priority': randint(100, 200)}


def mockRISKDATA():
    return {'name': "rds", 'priority': randint(20, 30)}


def mockALPHA():
    return {'name': "alpha", 'priority': 1}


def mockPRED():
    return {'name': "alpha.p201", 'priority': 1}


def mockPWGT():
    return {'name': "wgtset.dftwgt", 'priority': randint(500, 600)}


def mockMDA():
    return {'name': "MDA", 'priority': 2}


def mockMD():
    return {'name': "md", 'priority': randint(6, 10)}


def mockBKCK():
    return {'name': "bkck", 'priority': randint(900, 1000)}


def mockQRLOG():
    return {'name': "qrlog", 'priority': 1}


def mockCTM():
    return {'name': "ct", 'priority': randint(30, 40)}


def mockMCM():
    return {'name': "mcc", 'priority': 5}


def mockASPECT():
    return {'name': "aspect", 'priority': 9}


def mockPNL():
    return {'name': "pnl", 'priority': 900}


def mockTCM():
    return {'name': "tcm", 'priority': 9}


def mockDE():
    return {'name': "de", 'priority': 700}


def mockGMVAndSymbols(name):
    import math
    maxGMV = randint(1, 2) * 100000000 * random()
    currGMV = randint(0, math.floor(maxGMV))
    symbols = randint(100, 500)
    engaged = randint(0, symbols)
    return {
        'name': 'liqstgy',
        'currGMV': currGMV,
        'maxGMV': maxGMV,
        'symbols': symbols,
        'engaged': engaged,
        'priority': randint(500, 600)
    }


def mockLIQSTGY():
    return mockGMVAndSymbols('liqstgy')


def mockDummyTrading():
    return mockGMVAndSymbols('dummytrading')


def mockhedgestgy2():
    return mockGMVAndSymbols('hedgestgy2')


def mockS201():
    return mockGMVAndSymbols('preopen')


def mock():
    projects = ["brazil", "japan", "preopen", "useqau", "useqct"]
    hosts = ["spa_kbl22", "jpxa_kbl33", "njc_kbl187",
             "njc_kbl190", "fpis_jctsiml1111"]
    programs = [["BR_1", "BRALPH_1", "BRHEDG_1", "BRHEDG_2", "BRLQ_1", "BRMM_1", "BRMM_2", "BRRISK_1"],
                ["JP_3", "JP_4", "JPADRLIQ_1", "JPALPH_1", "JPALPH_2", "JPALPH_3", "JPALPH_4",
                 "JPAU_1", "JPAU_2", "JPAU_3", "JPAU_4", "JPALAU_1", "JPALAU_2", "JPALAU_3", "JPALAU_4",
                 "JPHEDG_1", "JPHEDG_2", "JPLQ_1", "JPLQ_2", "JPLQ_3", "JPLQ_4",
                 "JPRISK_1", "JPRISK_2", "JPRISK_3"],
                ["JCT_1", "JCT_2", "JCT_3", "JCT_4", "JCT_5", "JCT_6", "JCT_7", "JCT_8",
                 "JPADR_1", "JPADR_2", "JPADRHEDG_1", "JCTALPH_1",
                 "JCTHEDG_1", "JCTHEDG_2", "JCTHEDG_4", "JCTRISK_1", "JCTRISK_2", "JCTRISK_3", "JCTRISK_4",
                 "JCTRMM_1", "PMAN"],
                ["USACALPHA_1", "USACALPHA_2", "USACALPHA_3", "USACALPHA_4", "USACALPHA_5", "USACALPHA_6",
                 "USACHEDG_1", "USACRISK_1", "USACRISK_2", "USACTRADE_1"],
                ["IOC_1", "IOC_2", "IOC_3", "IOC_4", "IOI_1",
                 "IOIHEDG_1", "IOIRISK_1", "IOCRISK_1"]
                ]

    num = randint(0, 4)
    project = projects[num]
    host = hosts[num]
    program = Program.objects.get_or_none(name=choice(programs[num]))

    if program is None:
        return None

    newModuleIdx = randint(0, 35)
    if newModuleIdx == 0:
        newModuleInfo = mockPROGRAM()
        newModuleInfo['name'] = program.name
        program.update({'startTime': newModuleInfo['startTime']})
    elif newModuleIdx == 1:
        newModuleInfo = mockGWM()
    elif newModuleIdx == 2:
        newModuleInfo = mockRISK()
    elif newModuleIdx == 3:
        newModuleInfo = mockRMMSTATUS()
    elif newModuleIdx == 4:
        newModuleInfo = mockPECM()
    elif newModuleIdx == 5:
        newModuleInfo = mockPEALPHA()
    elif newModuleIdx == 6:
        newModuleInfo = mockLGBM()
    elif newModuleIdx == 7:
        newModuleInfo = mockRISKDATA()
    elif newModuleIdx == 8:
        newModuleInfo = mockALPHA()
    elif newModuleIdx == 9:
        newModuleInfo = mockPRED()
    elif newModuleIdx == 10:
        newModuleInfo = mockPWGT()
    elif newModuleIdx == 11:
        newModuleInfo = mockMDA()
    elif newModuleIdx == 12:
        newModuleInfo = mockMD()
    elif newModuleIdx == 13:
        newModuleInfo = mockBKCK()
    elif newModuleIdx == 14:
        newModuleInfo = mockQRLOG()
    elif newModuleIdx == 15:
        newModuleInfo = mockCTM()
    elif newModuleIdx == 16:
        newModuleInfo = mockMCM()
    elif newModuleIdx == 17:
        newModuleInfo = mockASPECT()
    elif newModuleIdx == 18:
        newModuleInfo = mockPNL()
    elif newModuleIdx == 19:
        newModuleInfo = mockTCM()
    elif newModuleIdx == 20:
        newModuleInfo = mockDE()
    elif newModuleIdx == 21:
        newModuleInfo = mockLIQSTGY()
    elif newModuleIdx == 22:
        newModuleInfo = mockDummyTrading()
    elif newModuleIdx == 23:
        newModuleInfo = mockhedgestgy2()
    elif newModuleIdx == 24:
        newModuleInfo = mockS201()
    else:
        newPidFlag = randint(0, 10)
        if newPidFlag > 8:
            program.update({'pid': program.pid + 1 if randint(0, 1) == 0 else program.pid - 1,
                            'reboots': program.reboots + 1})
            oldModules = Module.objects.select_related('program').filter(
                program=program).order_by('-ctime').first()

            logs = ["Everything is working perfectly.",
                    "Something is wrong, please take a look.",
                    "Critical alert detected, reboot now!"]
            logFlag = randint(0, 10)

            log = None
            if logFlag <= 6:
                log = Log.objects.addLog(program, logs[0], str(0))
            elif logFlag <= 8:
                log = Log.objects.addLog(program, logs[1], str(1))
            else:
                log = Log.objects.addLog(program, logs[2], str(2))

            sentModule = {}
            if oldModules is not None:
                oldModules = json.loads(oldModules.info)
                for oldModule in oldModules:
                    sentModule[oldModule["name"]] = oldModule

            return {
                'program_id': program.id,
                'program': program.name,
                'project_id': program.project.id,
                'project': program.project.name,
                'host_id': program.host.id,
                'host': program.host.name,
                'pid': program.pid,
                'reboots': program.reboots,
                'startTime': program.startTime,
                'updateTime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),
                'modules': sentModule,
                'log': {} if log is None else LogSerializer(log).data
            }
        else:
            return None

    newModuleName = newModuleInfo['name']

    oldModules = Module.objects.select_related('program').filter(
        program=program).order_by('-ctime').first()

    if oldModules is None:
        Module.objects.addModule(program, json.dumps([newModuleInfo]))
        return {
            'program_id': program.id,
            'program': program.name,
            'project_id': program.project.id,
            'project': program.project.name,
            'host_id': program.host.id,
            'host': program.host.name,
            'pid': program.pid,
            'reboots': program.reboots,
            'startTime': program.startTime,
            'updateTime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),
            'modules': {newModuleInfo["name"]: newModuleInfo},
        }
    else:
        oldModules = json.loads(oldModules.info)
        index = 0
        modified = False
        for oldModule in oldModules:
            if oldModule['name'] != newModuleName:
                index += 1
                continue

            if oldModule != newModuleInfo:
                oldModules[index] = newModuleInfo
                modified = True

            break

        if index >= len(oldModules):
            oldModules.append(newModuleInfo)
        elif not modified:
            return None

        sentModule = {}
        for oldModule in oldModules:
            sentModule[oldModule["name"]] = oldModule

        Module.objects.addModule(program, json.dumps(oldModules))

        return {
            'program_id': program.id,
            'program': program.name,
            'project_id': program.project.id,
            'project': program.project.name,
            'host_id': program.host.id,
            'host': program.host.name,
            'pid': program.pid,
            'reboots': program.reboots,
            'startTime': program.startTime,
            'updateTime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),
            'modules': sentModule
        }
