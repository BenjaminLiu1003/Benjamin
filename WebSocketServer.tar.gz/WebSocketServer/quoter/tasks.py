import errno
import socket
import struct
import time
from celery import shared_task
from channels.layers import get_channel_layer
from common.responseinfo import ResponseInfo
from asgiref.sync import async_to_sync
from .models import *
from .serializer import *

global isrunning
isrunning = True


def sigproc(signum, frame):
    global isrunning
    isrunning = False


def decode_packet(pkt):
    sz = len(pkt)
    message = struct.unpack('<%ds' % (sz), pkt)
    return message


class DummySender:
    def __init__(self, ip, port, ttl):
        self.multicast_group = (ip, port)
        self.ttl = ttl

    def receive(self):
        pass

    def destroy(self):
        pass


class MSender:
    def __init__(self, ip, port, ttl):
        self.multicast_group = (ip, port)
        self.ttl = ttl
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(1)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        ttl = struct.pack('b', self.ttl)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl)
        self.sock.bind(('', port))

        group = socket.inet_aton(ip)
        mreq = struct.pack('4sL', group, socket.INADDR_ANY)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

    def receive(self):
        try:
            message = self.sock.recvfrom(1400)
            return message
        except socket.timeout:
            return None
        except socket.error as e:
            if e.errno == errno.EINTR:
                return None
            else:
                raise

    def destroy(self):
        self.sock.close()


class CommandSender:
    def __init__(self, ip, port, ttl, dry):
        self.sender = DummySender(
            ip, port, ttl) if dry else MSender(ip, port, ttl)

    def receive(self):
        res = self.sender.receive()
        return res

    def destroy(self):
        self.sender.destroy()


@shared_task(ignore_result=True)
def listen():
    time.sleep(3)
    s = CommandSender("239.100.29.0", 65400, 1, False)
    while isrunning:
        # msg = s.receive()
        # if msg is None:
        #     time.sleep(10)
        #     continue

        time.sleep(2)

        from .mock import mock
        program = mock()
        if program is None:
            continue

        result = dict(ResponseInfo.GeneralGetSuccess.value,
                      data=dict(program=program))

        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)("notification", {
            'type': 'group_send',
            'message': result
        })

    s.destroy()
