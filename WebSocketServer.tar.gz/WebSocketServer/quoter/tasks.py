from socketserver import BaseRequestHandler, ThreadingUDPServer
import socket
import struct
import argparse
import time
import signal
import errno
from celery.signals import celeryd_after_setup
from celery import shared_task
from channels.layers import get_channel_layer
from common.responseinfo import ResponseInfo
from asgiref.sync import async_to_sync
from random import randint, choice
from .models import *
from .serializer import *

global isrunning
isrunning = True


def sigproc(signum, frame):
    global isrunning
    isrunning = False


def decode_packet(pkt):
    sz = len(pkt)
    message = struct.unpack('<%ds' % (sz), pkt)
    return message


class DummySender:
    def __init__(self, ip, port, ttl):
        self.multicast_group = (ip, port)
        self.ttl = ttl

    def receive(self):
        pass

    def destroy(self):
        pass


class MSender:
    def __init__(self, ip, port, ttl):
        self.multicast_group = (ip, port)
        self.ttl = ttl
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(1)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        ttl = struct.pack('b', self.ttl)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl)

        print("$$$$$$$$$$$$$$$$$$$$$$$$$")
        import threading
        th = threading.currentThread()
        print("Thread id: %d" % th.ident)
        print("Name: %s" % th.getName())
        self.sock.bind(('', port))
        print("$$$$$$$$$$$$$$$$$$$$$$$$$")

        group = socket.inet_aton(ip)
        mreq = struct.pack('4sL', group, socket.INADDR_ANY)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

    def receive(self):
        try:
            message = self.sock.recvfrom(1400)
            return message
        except socket.timeout:
            return None
        except socket.error as e:
            if e.errno == errno.EINTR:
                return None
            else:
                raise

    def destroy(self):
        self.sock.close()


class CommandSender:
    def __init__(self, ip, port, ttl, dry):
        self.sender = DummySender(
            ip, port, ttl) if dry else MSender(ip, port, ttl)

    def receive(self):
        res = self.sender.receive()
        return res
        # if res:
        #     print(struct.unpack('<%ds'%(len(res[0])), res[0]))
        #     print(res[1])

    def destroy(self):
        self.sender.destroy()


class TimeHandler(BaseRequestHandler):
    def handle(self):
        print('Got connection from', self.client_address)
        msg, sock = self.request
        print(msg)
        resp = time.ctime()
        sock.sendto(resp.encode(), self.client_address)


def updateDatabase(message):
    group = Group.objects.get_or_none(name=message['group'])
    if group is None:
        return

    program = Program.objects.get_or_none(name=message['name'])
    if program is None:
        return
    program.update({
        'group': group, 
        # 'host': message['host'],
        'pid': message['pid'],
        'reboots': message['reboots'] + 1 if message['pid'] == program.pid else message['reboots']
    })
    message['id'] = program.id
    message['group'] = group.id

    for module in message['modules']:
        if module['name'] == 'log':
            log = Log.objects.addLog(program, module['text'], module['level'])
            module['ctime'] = LogSerializer(log).data['ctime']
        elif module['name'] == 'component1':
            Component1.objects.addComponent1(
                program, module['orders'], module['trades'], module['fails'])
        elif module['name'] == 'component2':
            Component2.objects.addComponent2(
                program, module['currGMV'], module['maxGMV'])
        elif module['name'] == 'component3':
            Component3.objects.addComponent3(
                program, module['symbols'], module['engaged'])

def mock():
    message = {}

    groups = ["JCT", "JPAU", "JPHEDG", "JTRISK"]
    hosts = ['fpis_kbsiml14', 'fpis_kbsiml35', 'fpis_kbsiml66']
    group = choice(groups)
    if group == "JCT":
        program = group + "_" + str(randint(0, 17) + 1)
    elif group == "JPAU":
        program = group + "_" + str(randint(0, 11) + 1)
    elif group == "JPHEDG":
        program = group + "_" + str(randint(0, 15) + 1)
    else:
        program = group + "_" + str(randint(0, 18) + 1)

    message['group'] = group
    message['name'] = program
    program1 = Program.objects.get_or_none(name=program)
    message['host'] = program1.host.id#choice(hosts)
    message['reboots'] = program1.reboots
    message['pid'] = randint(6666, 8888)
    
    cnt = randint(0, 1000)
    if cnt % 4 == 0:
        orders = randint(0, 1000)
        trades = randint(0, orders)
        fails = orders - trades
        if randint(0, 1000) % 2 == 0:
          trades = max(trades, fails)
        else:
          trades = min(trades, fails)
        fails = orders - trades 
        message['modules'] = [dict(
          name="component1", orders=orders, trades=trades, fails=fails
        )]
    elif cnt % 4 == 1:
        maxGMV = randint(10000000, 20000000)
        currGMV = randint(0, maxGMV)
        message['modules'] = [dict(
          name="component2", currGMV=currGMV, maxGMV=maxGMV
        )]
    elif cnt % 4 == 2:
        symbols = randint(0, 1000)
        engaged = randint(0, symbols)
        message['modules'] = [dict(
            name="component3", symbols=symbols, engaged=engaged
        )]
    else:
        logs = ["Everything is working perfectly.",
                "Something is wrong, please take a look.",
                "Critical alert detected, reboot now!"]
        tmp = 2 #randint(0, 2)
        message['modules'] = [dict(
          name="log", text=logs[tmp], level=str(tmp)
        )]

    return message


@shared_task(ignore_result=True)
def listen():
    time.sleep(3)
    s = CommandSender("239.100.29.0", 65400, 1, False)
    while isrunning:
        # msg = s.receive()
        # if msg is None:
        #     time.sleep(10)
        #     continue
        program = mock()
        updateDatabase(program)
        time.sleep(2)

        result = dict(ResponseInfo.GeneralGetSuccess.value,
                      data=dict(program=program))

        # Send message to WebSocket
        # await self.send(text_data=json.dumps({
        #     'message': message
        # }))
        channel_layer = get_channel_layer()
        print("result")
        print(result)
        async_to_sync(channel_layer.group_send)("notification", {
            'type': 'group_send_program', #'receive',
            'message': result  # 'async_to_sync function'
        })
        # async_to_sync(channel_layer.group_send)("host_fpis_kbsiml14", {
        #   'type': 'receive',
        #   'message': data
        # })
        # async_to_sync(channel_layer.group_send)("host_fpis_kbsiml35", {
        #   'type': 'receive',
        #   'message': data
        # })
        # async_to_sync(channel_layer.group_send)("host_fpis_kbsiml66", {
        #   'type': 'receive',
        #   'message': data
        # })

    print("destroy socket...")
    s.destroy()
    # serv = ThreadingUDPServer(('', 65400), TimeHandler)
    # serv.serve_forever()

# listen()
