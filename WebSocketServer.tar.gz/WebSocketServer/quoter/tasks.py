from socketserver import BaseRequestHandler, ThreadingUDPServer
import socket
import struct
import argparse
import time
import signal
import errno
from celery.signals import celeryd_after_setup
from celery import shared_task
from channels.layers import get_channel_layer
from common.responseinfo import ResponseInfo
from asgiref.sync import async_to_sync
from random import randint, random, choice
from .models import *
from .serializer import *
import json

global isrunning
isrunning = True


def sigproc(signum, frame):
    global isrunning
    isrunning = False


def decode_packet(pkt):
    sz = len(pkt)
    message = struct.unpack('<%ds' % (sz), pkt)
    return message


class DummySender:
    def __init__(self, ip, port, ttl):
        self.multicast_group = (ip, port)
        self.ttl = ttl

    def receive(self):
        pass

    def destroy(self):
        pass


class MSender:
    def __init__(self, ip, port, ttl):
        self.multicast_group = (ip, port)
        self.ttl = ttl
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(1)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        ttl = struct.pack('b', self.ttl)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, ttl)

        print("$$$$$$$$$$$$$$$$$$$$$$$$$")
        import threading
        th = threading.currentThread()
        print("Thread id: %d" % th.ident)
        print("Name: %s" % th.getName())
        self.sock.bind(('', port))
        print("$$$$$$$$$$$$$$$$$$$$$$$$$")

        group = socket.inet_aton(ip)
        mreq = struct.pack('4sL', group, socket.INADDR_ANY)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

    def receive(self):
        try:
            message = self.sock.recvfrom(1400)
            return message
        except socket.timeout:
            return None
        except socket.error as e:
            if e.errno == errno.EINTR:
                return None
            else:
                raise

    def destroy(self):
        self.sock.close()


class CommandSender:
    def __init__(self, ip, port, ttl, dry):
        self.sender = DummySender(
            ip, port, ttl) if dry else MSender(ip, port, ttl)

    def receive(self):
        res = self.sender.receive()
        return res
        # if res:
        #     print(struct.unpack('<%ds'%(len(res[0])), res[0]))
        #     print(res[1])

    def destroy(self):
        self.sender.destroy()


class TimeHandler(BaseRequestHandler):
    def handle(self):
        print('Got connection from', self.client_address)
        msg, sock = self.request
        print(msg)
        resp = time.ctime()
        sock.sendto(resp.encode(), self.client_address)


# def updateDatabase(message):
#     group = Group.objects.get_or_none(name=message['group'])
#     if group is None:
#         return

#     program = Program.objects.get_or_none(name=message['name'])
#     if program is None:
#         return
#     program.update({
#         'group': group,
#         # 'host': message['host'],
#         'pid': message['pid'],
#         'reboots': message['reboots'] + 1 if message['pid'] == program.pid else message['reboots']
#     })
#     message['id'] = program.id
#     message['group'] = group.id

#     for module in message['modules']:
#         if module['name'] == 'log':
#             log = Log.objects.addLog(program, module['text'], module['level'])
#             module['ctime'] = LogSerializer(log).data['ctime']
#         elif module['name'] == 'component1':
#             Component1.objects.addComponent1(
#                 program, module['orders'], module['trades'], module['fails'])
#         elif module['name'] == 'component2':
#             Component2.objects.addComponent2(
#                 program, module['currGMV'], module['maxGMV'])
#         elif module['name'] == 'component3':
#             Component3.objects.addComponent3(
#                 program, module['symbols'], module['engaged'])


def mockPROGRAM():
    return {
        # 'type': "PROGRAM",
        'startTime': randint(1653500000, 1653550000)
    }

def mockGWM():
    orders = randint(500, 1000)
    trades = randint(0, orders)
    fails = orders - trades
    return {
        'name': 'gwm',
        'orders': orders,
        'trades': trades,
        'fails': fails,
        'priority': 10,
    }


def mockRISK():
    return {'name': 'risk', 'priority': randint(30, 50)}


def mockRMMSTATUS():
    return {'name': "rmmst", 'priority': randint(500, 600)}


def mockPECM():
    return {'name': "pecm", 'priority': randint(900, 1000)}


def mockPEALPHA():
    return {'name': "preoo", 'priority': randint(500, 600)}


def mockLGBM():
    names = ["LGBM_OO_0900", "LGBM_OO_VWAP", "LGBM_OO_Flow", "LGBM_OO_5m"]
    return {'name': choice(names), 'priority': randint(100, 200)}


def mockRISKDATA():
    return {'name': "rds", 'priority': randint(20, 30)}


def mockALPHA():
    return {'name': "alpha", 'priority': 1}


def mockPRED():
    return {'name': "alpha.p201", 'priority': 1}


def mockPWGT():
    return {'name': "wgtset.dftwgt", 'priority': randint(500, 600)}


def mockMDA():
    return {'name': "MDA", 'priority': 2}


def mockMD():
    return {'name': "md", 'priority': randint(6, 10)}


def mockBKCK():
    return {'name': "bkck", 'priority': randint(900, 1000)}


def mockQRLOG():
    return {'name': "qrlog", 'priority': 1}


def mockCTM():
    return {'name': "ct", 'priority': randint(30, 40)}


def mockMCM():
    return {'name': "mcc", 'priority': 5}


def mockASPECT():
    return {'name': "aspect", 'priority': 9}


def mockPNL():
    return {'name': "pnl", 'priority': 900}


def mockTCM():
    return {'name': "tcm", 'priority': 9}


def mockDE():
    return {'name': "de", 'priority': 700}


def mockGMVAndSymbols(name):
    import math
    maxGMV = randint(1, 2) * 100000000 * random()
    currGMV = randint(0, math.floor(maxGMV))
    symbols = randint(100, 500)
    engaged = randint(0, symbols)
    return {
        'name': 'liqstgy',
        'currGMV': currGMV,
        'maxGMV': maxGMV,
        'symbols': symbols,
        'engaged': engaged,
        'priority': randint(500, 600)
    }


def mockLIQSTGY():
    return mockGMVAndSymbols('liqstgy')


def mockDummyTrading():
    return mockGMVAndSymbols('dummytrading')


def mockhedgestgy2():
    return mockGMVAndSymbols('hedgestgy2')


def mockS201():
    return mockGMVAndSymbols('preopen')


def mock1():
    projects = ["brazil", "japan", "preopen", "useqau", "useqct"]
    hosts = ["spa_kbl22", "jpxa_kbl33", "njc_kbl187",
             "njc_kbl190", "fpis_jctsiml1111"]
    programs = [["BR_1", "BRALPH_1", "BRHEDG_1", "BRHEDG_2", "BRLQ_1", "BRMM_1", "BRMM_2", "BRRISK_1"],
                ["JP_3", "JP_4", "JPADRLIQ_1", "JPALPH_1", "JPALPH_2", "JPALPH_3", "JPALPH_4",
                 "JPAU_1", "JPAU_2", "JPAU_3", "JPAU_4", "JPALAU_1", "JPALAU_2", "JPALAU_3", "JPALAU_4",
                 "JPHEDG_1", "JPHEDG_2", "JPLQ_1", "JPLQ_2", "JPLQ_3", "JPLQ_4",
                 "JPRISK_1", "JPRISK_2", "JPRISK_3"],
                ["JCT_1", "JCT_2", "JCT_3", "JCT_4", "JCT_5", "JCT_6", "JCT_7", "JCT_8",
                 "JPADR_1", "JPADR_2", "JPADRHEDG_1", "JCTALPH_1",
                 "JCTHEDG_1", "JCTHEDG_2", "JCTHEDG_4", "JCTRISK_1", "JCTRISK_2", "JCTRISK_3", "JCTRISK_4",
                 "JCTRMM_1", "PMAN"],
                ["USACALPHA_1", "USACALPHA_2", "USACALPHA_3", "USACALPHA_4", "USACALPHA_5", "USACALPHA_6",
                 "USACHEDG_1", "USACRISK_1", "USACRISK_2", "USACTRADE_1"],
                ["IOC_1", "IOC_2", "IOC_3", "IOC_4", "IOI_1",
                 "IOIHEDG_1", "IOIRISK_1", "IOCRISK_1"]
                ]

    num = randint(0, 4)
    project = projects[num]
    host = hosts[num]
    program = Program.objects.get_or_none(name=choice(programs[num]))

    if program is None:
        return None

    newModuleIdx = randint(0, 35)
    if newModuleIdx == 0:
        newModuleInfo = mockPROGRAM()
        newModuleInfo['name'] = program.name
        program.update({'startTime': newModuleInfo['startTime']})
    elif newModuleIdx == 1:
        newModuleInfo = mockGWM()
    elif newModuleIdx == 2:
        newModuleInfo = mockRISK()
    elif newModuleIdx == 3:
        newModuleInfo = mockRMMSTATUS()
    elif newModuleIdx == 4:
        newModuleInfo = mockPECM()
    elif newModuleIdx == 5:
        newModuleInfo = mockPEALPHA()
    elif newModuleIdx == 6:
        newModuleInfo = mockLGBM()
    elif newModuleIdx == 7:
        newModuleInfo = mockRISKDATA()
    elif newModuleIdx == 8:
        newModuleInfo = mockALPHA()
    elif newModuleIdx == 9:
        newModuleInfo = mockPRED()
    elif newModuleIdx == 10:
        newModuleInfo = mockPWGT()
    elif newModuleIdx == 11:
        newModuleInfo = mockMDA()
    elif newModuleIdx == 12:
        newModuleInfo = mockMD()
    elif newModuleIdx == 13:
        newModuleInfo = mockBKCK()
    elif newModuleIdx == 14:
        newModuleInfo = mockQRLOG()
    elif newModuleIdx == 15:
        newModuleInfo = mockCTM()
    elif newModuleIdx == 16:
        newModuleInfo = mockMCM()
    elif newModuleIdx == 17:
        newModuleInfo = mockASPECT()
    elif newModuleIdx == 18:
        newModuleInfo = mockPNL()
    elif newModuleIdx == 19:
        newModuleInfo = mockTCM()
    elif newModuleIdx == 20:
        newModuleInfo = mockDE()
    elif newModuleIdx == 21:
        newModuleInfo = mockLIQSTGY()
    elif newModuleIdx == 22:
        newModuleInfo = mockDummyTrading()
    elif newModuleIdx == 23:
        newModuleInfo = mockhedgestgy2()
    elif newModuleIdx == 24:
        newModuleInfo = mockS201()
    else:
        newPidFlag = randint(0, 10)
        if newPidFlag > 8:
            program.update({'pid': program.pid + 1 if randint(0, 1) == 0 else program.pid - 1,
                            'reboots': program.reboots + 1})
            oldModules = Module.objects.select_related('program').filter(
                program=program).order_by('-ctime').first()

            logs = ["Everything is working perfectly.",
                "Something is wrong, please take a look.",
                "Critical alert detected, reboot now!"]
            logFlag = randint(0, 2)

            log = None
            if logFlag == 2:
              log = Log.objects.addLog(program, logs[2], str(2))

            sentModule = {}
            if oldModules is not None:
              oldModules = json.loads(oldModules.info)
              for oldModule in oldModules:
                sentModule[oldModule["name"]] = oldModule

            return {
                'program_id': program.id,
                'program': program.name,
                'project_id': program.project.id,
                'project': program.project.name,
                'host_id': program.host.id,
                'host': program.host.name,
                'pid': program.pid,
                'reboots': program.reboots,
                'startTime': program.startTime,
                'updateTime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),
                'modules': sentModule,
                'log': {} if log is None else LogSerializer(log).data 
            }
        else:
            return None

    newModuleName = newModuleInfo['name']

    oldModules = Module.objects.select_related('program').filter(
        program=program).order_by('-ctime').first()

    if oldModules is None:
        Module.objects.addModule(program, json.dumps([newModuleInfo]))
        return {
            'program_id': program.id,
            'program': program.name,
            'project_id': program.project.id,
            'project': program.project.name,
            'host_id': program.host.id,
            'host': program.host.name,
            'pid': program.pid,
            'reboots': program.reboots,
            'startTime': program.startTime,
            'updateTime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),
            'modules': {newModuleInfo["name"]: newModuleInfo},
        }
    else:
        oldModules = json.loads(oldModules.info)
        index = 0
        modified = False
        for oldModule in oldModules:
            if oldModule['name'] != newModuleName:
                index += 1
                continue

            if oldModule != newModuleInfo:
                oldModules[index] = newModuleInfo
                modified = True

            break

        if index >= len(oldModules):
            oldModules.append(newModuleInfo)
        elif not modified:
            return None

        sentModule = {}
        for oldModule in oldModules:
          sentModule[oldModule["name"]] = oldModule

        Module.objects.addModule(program, json.dumps(oldModules))

        return {
            'program_id': program.id,
            'program': program.name,
            'project_id': program.project.id,
            'project': program.project.name,
            'host_id': program.host.id,
            'host': program.host.name,
            'pid': program.pid,
            'reboots': program.reboots,
            'startTime': program.startTime,
            'updateTime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),
            'modules': sentModule
        }


def mock():
    message = {}

    groups = ["JCT", "JPAU", "JPHEDG", "JTRISK"]
    hosts = ['fpis_kbsiml14', 'fpis_kbsiml35', 'fpis_kbsiml66']
    group = choice(groups)
    if group == "JCT":
        program = group + "_" + str(randint(0, 17) + 1)
    elif group == "JPAU":
        program = group + "_" + str(randint(0, 11) + 1)
    elif group == "JPHEDG":
        program = group + "_" + str(randint(0, 15) + 1)
    else:
        program = group + "_" + str(randint(0, 18) + 1)

    message['group'] = group
    message['name'] = program
    program1 = Program.objects.get_or_none(name=program)
    message['host'] = program1.host.id  # choice(hosts)
    message['reboots'] = program1.reboots
    message['pid'] = randint(6666, 8888)

    cnt = randint(0, 1000)
    if cnt % 4 == 0:
        orders = randint(0, 1000)
        trades = randint(0, orders)
        fails = orders - trades
        if randint(0, 1000) % 2 == 0:
            trades = max(trades, fails)
        else:
            trades = min(trades, fails)
        fails = orders - trades
        message['modules'] = [dict(
            name="component1", orders=orders, trades=trades, fails=fails
        )]
    elif cnt % 4 == 1:
        maxGMV = randint(10000000, 20000000)
        currGMV = randint(0, maxGMV)
        message['modules'] = [dict(
            name="component2", currGMV=currGMV, maxGMV=maxGMV
        )]
    elif cnt % 4 == 2:
        symbols = randint(0, 1000)
        engaged = randint(0, symbols)
        message['modules'] = [dict(
            name="component3", symbols=symbols, engaged=engaged
        )]
    else:
        logs = ["Everything is working perfectly.",
                "Something is wrong, please take a look.",
                "Critical alert detected, reboot now!"]
        tmp = 2  # randint(0, 2)
        message['modules'] = [dict(
            name="log", text=logs[tmp], level=str(tmp)
        )]

    return message


@shared_task(ignore_result=True)
def listen():
    time.sleep(3)
    s = CommandSender("239.100.29.0", 65400, 1, False)
    while isrunning:
        # msg = s.receive()
        # if msg is None:
        #     time.sleep(10)
        #     continue
        # program = mock()
        # updateDatabase(program)

        time.sleep(2)

        program = mock1()
        if program is None:
            continue

        result = dict(ResponseInfo.GeneralGetSuccess.value,
                      data=dict(program=program))

        # Send message to WebSocket
        # await self.send(text_data=json.dumps({
        #     'message': message
        # }))
        channel_layer = get_channel_layer()
        # print("result")
        # print(result)
        async_to_sync(channel_layer.group_send)("notification", {
            'type': 'group_send_program',  # 'receive',
            'message': result  # 'async_to_sync function'
        })
        # async_to_sync(channel_layer.group_send)("host_fpis_kbsiml14", {
        #   'type': 'receive',
        #   'message': data
        # })
        # async_to_sync(channel_layer.group_send)("host_fpis_kbsiml35", {
        #   'type': 'receive',
        #   'message': data
        # })
        # async_to_sync(channel_layer.group_send)("host_fpis_kbsiml66", {
        #   'type': 'receive',
        #   'message': data
        # })

    print("destroy socket...")
    s.destroy()
    # serv = ThreadingUDPServer(('', 65400), TimeHandler)
    # serv.serve_forever()

# listen()
