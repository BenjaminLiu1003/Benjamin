from django.core.exceptions import ObjectDoesNotExist
from django.db import models

class GroupManager(models.Manager):
  def addGroup(self, name):
    group = self.model(name=name)
    group.save()
    return group
  
  def get_or_none(self, **kwargs):
    try:
      return self.get(**kwargs)
    except ObjectDoesNotExist:
      return None

class HostManager(models.Manager):
  def addHost(self, name):
    host = self.model(name=name)
    host.save()
    return host
  
  def get_or_none(self, **kwargs):
    try:
      return self.get(**kwargs)
    except ObjectDoesNotExist:
      return None

class ProgramManager(models.Manager):
    def addProgram(self, group, name, host, pid):
        if isinstance(group, str):
          group = Group.objects.get(name=group)
        if isinstance(host, str):
          host = Host.objects.get(name=host)
        program = self.model(group=group, name=name, host=host, pid=pid)
        program.save()
        return program

    def get_or_none(self, **kwargs):
        try:
            return self.get(**kwargs)
        except ObjectDoesNotExist:
            return None

class LogManager(models.Manager):
  def addLog(self, program, text, level):
      if isinstance(program, str):
        program = Program.objects.get(name=program)
      
      log = self.model(program=program, text=text, level=level)
      log.save()
      return log

class Component1Manager(models.Manager):
  def addComponent1(self, program, orders, trades, fails):
    if isinstance(program, str):
      program = Program.objects.get(name=program)
    
    component1 = self.model(program=program, orders=orders, trades=trades, fails=fails)
    component1.save()
    return component1
  
  def get_or_none(self, **kwargs):
    try:
      return self.get(**kwargs)
    except ObjectDoesNotExist:
      return None

class Component2Manager(models.Manager):
  def addComponent2(self, program, currGMV, maxGMV):
    if isinstance(program, str):
      program = Program.objects.get(name=program)
    
    component2 = self.model(program=program, currGMV=currGMV, maxGMV=maxGMV)
    component2.save()
    return component2
  
  def get_or_none(self, **kwargs):
    try:
      return self.get(**kwargs)
    except ObjectDoesNotExist:
      return None

class Component3Manager(models.Manager):
  def addComponent3(self, program, symbols, engaged):
    if isinstance(program, str):
      program = Program.objects.get(name=program)
    
    component3 = self.model(program=program, symbols=symbols, engaged=engaged)
    component3.save()
    return component3
  
  def get_or_none(self, **kwargs):
    try:
      return self.get(**kwargs)
    except ObjectDoesNotExist:
      return None

class Group(models.Model):
  name = models.CharField('name', max_length=20, unique=True)

  objects = GroupManager()

  def __str__(self):
    return self.name

class Host(models.Model):
  name = models.CharField('name', max_length=20, unique=True)

  objects = HostManager()

  def __str__(self):
    return self.name

class Program(models.Model):
    group = models.ForeignKey(Group, on_delete=models.CASCADE)
    name = models.CharField('name', max_length=20,
                            unique=True, blank=False, null=False)
    host = models.ForeignKey(Host, on_delete=models.CASCADE)
    pid = models.PositiveIntegerField('pid')
    reboots = models.PositiveIntegerField('reboots', default=0)

    objects = ProgramManager()

    class Meta:
        # db_table = "quoter_program"
        verbose_name = "Program"
        verbose_name_plural = "Programs"

    def __str__(self):
        return self.name

    def update(self, info):
      for key, value in info.items():
        if hasattr(self, key) and value is not None:
          setattr(self, key, value)
        self.save()

    def toJSON(self):
        fields = []
        for field in self._meta.fields:
            fields.append(field.name)

        d = {}
        for attr in fields:
            d[attr] = getattr(self, attr)

        return d

class Log(models.Model):
    program = models.ForeignKey(Program, on_delete=models.CASCADE)
    text = models.CharField(max_length=500)
    ctime = models.DateTimeField('created time', auto_now_add=True)

    SUCCESS = '0'
    WARNING = '1'
    ALERT = '2'
    LEVEL_CHOICES = (
      (SUCCESS, 'success'),
      (WARNING, 'warning'),
      (ALERT, 'alert')
    )
    level = models.CharField('level', max_length=1, choices=LEVEL_CHOICES, default=SUCCESS)

    objects = LogManager()

class Component1(models.Model):
    program = models.ForeignKey(Program, on_delete=models.CASCADE)
    orders = models.PositiveBigIntegerField('orders', default=0)
    trades = models.PositiveBigIntegerField('trades', default=0)
    fails = models.PositiveBigIntegerField('fails', default=0)
    ctime = models.DateTimeField('created time', auto_now_add=True)

    objects = Component1Manager()


class Component2(models.Model):
    program = models.ForeignKey(Program, on_delete=models.CASCADE)
    currGMV = models.PositiveBigIntegerField('currGMV', default=0)
    maxGMV = models.PositiveBigIntegerField('maxGMV', default=0)
    ctime = models.DateTimeField('created time', auto_now_add=True)
    
    objects = Component2Manager()


class Component3(models.Model):
    program = models.ForeignKey(Program, on_delete=models.CASCADE)
    symbols = models.PositiveIntegerField('symbols', default=0)
    engaged = models.PositiveIntegerField('engaged', default=0)
    ctime = models.DateTimeField('created time', auto_now_add=True)

    objects = Component3Manager()
