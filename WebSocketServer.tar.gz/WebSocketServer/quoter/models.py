from django.core.exceptions import ObjectDoesNotExist
from django.db import models


class ProjectManager(models.Manager):
    def addProject(self, name):
        project = self.model(name=name)
        project.save()
        return project

    def get_or_none(self, **kwargs):
        try:
            return self.get(**kwargs)
        except ObjectDoesNotExist:
            return None


class HostManager(models.Manager):
    def addHost(self, name):
        host = self.model(name=name)
        host.save()
        return host

    def get_or_none(self, **kwargs):
        try:
            return self.get(**kwargs)
        except ObjectDoesNotExist:
            return None


class ProgramManager(models.Manager):
    def addProgram(self, name, project, host, pid):
        if isinstance(project, str):
            project = Project.objects.get(name=project)
        if isinstance(host, str):
            host = Host.objects.get(name=host)

        if project is None or host is None:
            return None

        program = self.model(name=name, project=project, host=host, pid=pid)
        program.save()
        return program

    def get_or_none(self, **kwargs):
        try:
            return self.get(**kwargs)
        except ObjectDoesNotExist:
            return None


class LogManager(models.Manager):
    def addLog(self, program, text, level):
        if isinstance(program, str):
            program = Program.objects.get(name=program)

        log = self.model(program=program, text=text, level=level)
        log.save()
        return log


class ModuleManager(models.Manager):
    def addModule(self, program, info):
        if isinstance(program, str):
            program = Program.objects.get_or_none(name=program)

        if program is None:
            return None

        module = self.model(program=program, info=info)
        module.save()
        return module

    def get_or_none(self, **kwargs):
        try:
            return self.get(**kwargs)
        except ObjectDoesNotExist:
            return None


class Project(models.Model):
    name = models.CharField('name', max_length=20, unique=True)

    objects = ProjectManager()

    def __str__(self):
        return self.name

    def natural_key(self):
        return self.name


class Host(models.Model):
    name = models.CharField('name', max_length=20, unique=True)

    objects = HostManager()

    def __str__(self):
        return self.name

    def natural_key(self):
        return self.name


class Program(models.Model):
    name = models.CharField('name', max_length=20,
                            unique=True, blank=False, null=False)
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    host = models.ForeignKey(Host, on_delete=models.CASCADE)
    pid = models.PositiveIntegerField('pid')
    startTime = models.PositiveBigIntegerField('start_time', default=0)
    reboots = models.PositiveIntegerField('reboots', default=0)

    objects = ProgramManager()

    class Meta:
        # db_table = "quoter_program"
        verbose_name = "Program"
        verbose_name_plural = "Programs"

    def __str__(self):
        return self.name

    def update(self, info):
        for key, value in info.items():
            if hasattr(self, key) and value is not None:
                setattr(self, key, value)
            self.save()

    def toJSON(self):
        fields = []
        for field in self._meta.fields:
            fields.append(field.name)

        d = {}
        for attr in fields:
            d[attr] = getattr(self, attr)

        return d


class Module(models.Model):
    program = models.ForeignKey(Program, on_delete=models.CASCADE)
    info = models.CharField(max_length=500)
    ctime = models.DateTimeField('created time', auto_now_add=True)

    objects = ModuleManager()


class Log(models.Model):
    program = models.ForeignKey(Program, on_delete=models.CASCADE)
    text = models.CharField(max_length=500)
    ctime = models.DateTimeField('created time', auto_now_add=True)

    SUCCESS = '0'
    WARNING = '1'
    ALERT = '2'
    LEVEL_CHOICES = (
        (SUCCESS, 'success'),
        (WARNING, 'warning'),
        (ALERT, 'alert')
    )
    level = models.CharField('level', max_length=1,
                             choices=LEVEL_CHOICES, default=SUCCESS)

    objects = LogManager()
