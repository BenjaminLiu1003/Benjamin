from django.apps import AppConfig

class QuoterConfig(AppConfig):
  name = 'quoter'