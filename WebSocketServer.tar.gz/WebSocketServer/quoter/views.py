import json
from django.views import View
from django.http import HttpResponse, JsonResponse, StreamingHttpResponse
from django.utils import timezone
from django.utils.encoding import escape_uri_path
from common.responseinfo import ResponseInfo

class AllQuoters(View):
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        quoters = [
            dict(first=dict(pg="JPRISK_2", host="fpis-kbsiml35", pid=121083),
                second=dict(name='gwm', orders=0, fails=0, 
                trades=0)),
            {
                'first': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'second': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'first': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'second': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'first': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'second': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'first': {'pg': "JCTRISK_2", 'host': "fpis-kbsiml14", 'pid': 1221},
                'second': {'name': 'JCTRISK_2', 'type': 'PROGRAM', 'startTime': 1652946619}
            },
            {
                'first': {'pg': "JCTRISK_1", 'host': "fpis-kbsiml14", 'pid': 1200},
                'second': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3014, 'engaged': 3014}
            },
            {
                'first': {'pg': 'JCTRMM_1', 'host': 'fpis-kbsiml14', 'pid': 1299},
                'second': {'name': 'rmm', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3117, 'engaged': 3117}
            },
            {
                'first': {'pg': 'JCT_4', 'host': 'fpis-kbsiml14', 'pid': 1089},
                'second': {'name': 'LGBM_00_5m', 'type': 'LGBM', 'priority': 200}
            },
            {
                'first': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'second': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'first': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'second': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'first': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'second': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'first': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'second': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'first': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'second': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'first': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'second': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'first': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'second': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'first': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'second': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            },
            {
                'first': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
                'second': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
            },
            {
                'first': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
                'second': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
            },
            {
                'first': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
                'second': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
            },
            {
                'first': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
                'second': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
            }
        ]
        result = dict(ResponseInfo.GeneralGetSuccess.value,
                      data = dict(quoters=quoters, total_num=len(quoters)))
        return JsonResponse(result)