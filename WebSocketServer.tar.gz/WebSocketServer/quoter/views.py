from django.views import View
from django.http import JsonResponse
from common.responseinfo import ResponseInfo

class AllQuoters(View):
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        result = dict(ResponseInfo.GeneralGetSuccess.value)
        return JsonResponse(result)