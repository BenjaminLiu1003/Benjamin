import asyncio
import datetime
import json
from this import d
from unittest import case
from asgiref.sync import sync_to_async, async_to_sync
from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer
from common.responseinfo import ResponseInfo
from django.core import serializers

from quoter.serializer import *
from .models import *


@sync_to_async
def updateProgram(message):
    group = Group.objects.get_or_none(name=message['group'])
    if group is None:
        return

    program = Program.objects.get_or_none(name=message['name'])
    if program is None:
        return
    program.update({
        'group': group, 'host': message['host'], 'pid': message['pid']
    })
    message['id'] = program.id
    message['group'] = group.id

    for module in message['modules']:
        if module['name'] == 'log':
            log = Log.objects.addLog(program, module['text'], module['level'])
            module['ctime'] = LogSerializer(log).data['ctime']
        elif module['name'] == 'component1':
            Component1.objects.addComponent1(
                program, module['orders'], module['trades'], module['fails'])
        elif module['name'] == 'component2':
            Component2.objects.addComponent2(
                program, module['currGMV'], module['maxGMV'])
        elif module['name'] == 'component3':
            Component3.objects.addComponent3(
                program, module['symbols'], module['engaged'])


@sync_to_async
def getAllProgramsForHost(host):
    groups = GroupSerializer(list(Group.objects.all()), many=True).data

    programs = list(Program.objects.filter(host=host))
    programs = ProgramSerializer(programs, many=True).data

    logsNum = Log.objects.count()
    if logsNum > 0:
        logs = list(Log.objects.order_by('ctime')[
                    max(0, logsNum - 10):logsNum])
        logs = LogSerializer(logs, many=True).data
    else:
        logs = None

    for program in programs:
        modules = []
        component1 = Component1.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component1 is not None:
            modules.append(dict(name="component1", orders=component1.orders,
                           trades=component1.trades, fails=component1.fails))
        else:
            modules.append(dict(name="component1"))

        component2 = Component2.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component2 is not None:
            modules.append(
                dict(name="component2", currGMV=component2.currGMV, maxGMV=component2.maxGMV))
        else:
            modules.append(dict(name="component2"))

        component3 = Component3.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component3 is not None:
            modules.append(
                dict(name="component3", symbols=component3.symbols, engaged=component3.engaged))
        else:
            modules.append(dict(name="component3"))

        program['modules'] = modules

    if logs is not None:
        return dict(groups=groups, programs=programs, logs=logs)
    else:
        return dict(groups=groups, programs=programs)


@sync_to_async
def getAllPrograms():
    groups = GroupSerializer(list(Group.objects.all()), many=True).data

    programs = list(Program.objects.all())
    programs = ProgramSerializer(programs, many=True).data

    logsNum = Log.objects.count()
    if logsNum > 0:
        logs = list(Log.objects.order_by('ctime')[
                    max(0, logsNum - 10):logsNum])
        logs = LogSerializer(logs, many=True).data
        print(logs)
    else:
        logs = None

    for program in programs:
        modules = []
        component1 = Component1.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component1 is not None:
            modules.append(dict(name="component1", orders=component1.orders,
                           trades=component1.trades, fails=component1.fails))
        else:
            modules.append(dict(name="component1"))

        component2 = Component2.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component2 is not None:
            modules.append(
                dict(name="component2", currGMV=component2.currGMV, maxGMV=component2.maxGMV))
        else:
            modules.append(dict(name="component2"))

        component3 = Component3.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component3 is not None:
            modules.append(
                dict(name="component3", symbols=component3.symbols, engaged=component3.engaged))
        else:
            modules.append(dict(name="component3"))

        program['modules'] = modules

    if logs is not None:
        return dict(groups=groups, programs=programs, logs=logs)
    else:
        return dict(groups=groups, programs=programs)


class QuoterConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        # self.room_name = self.scope['url_route']['kwargs']['room_name']
        # self.room_group_name = 'chat_%s' % self.room_name

        # self.level = self.scope['query_string']['level'] // unfinished here, need to split b'level=all&key=all'
        # self.key = self.scope['query_string']['key']
        # self.watch_name = self.level + '_' + self.key

        print("Connect....", self.scope)
        print("Channel_name....", self.channel_name)
        print("Channel_layer...", self.channel_layer)
        self.level = self.scope['url_route']['kwargs']['level']
        self.key = self.scope['url_route']['kwargs']['key']

        # self.scope['url_route']['kwargs']['watch_name']
        self.watch_name = self.level + '_' + self.key

        # Join room group
        await self.channel_layer.group_add(
            self.watch_name,
            self.channel_name
        )

        await self.accept()

        # loopRun()
        # programs = sync_to_async(serializers.serialize)("json", Program.objects.all())
        # programs = await database_sync_to_async(list)(Program.objects.all())
        # programs = await database_sync_to_async(Program.objects.all)()
        # print(programs)
        # programs = await sync_to_async(ProgramSerializer)(programs, many=True)
        # programs = await getAllPrograms()# await programs.data
        # print(programs)
        # print(programs)
        # programs = await ProgramSerializer(programs, many=True)
        # programs = programs.data
        # programs = await database_sync_to_async(Program.objects.all)()
        # await self.send(text_data=json.dumps(programs))
        # await self.send(text_data=json.dumps(programs))

        if self.level == 'host':
            await self.send(text_data=json.dumps(dict(ResponseInfo.GeneralGetSuccess.value,
                                                      data=await getAllProgramsForHost(self.key))))
        else:
          await self.send(text_data=json.dumps(dict(ResponseInfo.GeneralGetSuccess.value,
                                                  data=await getAllPrograms()
                                                  # data=serializers.serialize(
                                                  #     'json', programs, fields=('name', 'pid'))
                                                  # data=serializers.serialize(
                                                  #     'json', programs)
                                                  )))

        # await self.send(text_data=json.dumps({
        #   'type': 'first',
        #   'message1': "success",
        #   "testkey": 'TestValue'
        # }))

    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.watch_name,
            self.channel_name

        )

    # Receive message from WebSocket
    async def receive(self, text_data):
        message = text_data['message']
        print(self.watch_name, " received.....", message)

        # text_data_json = json.loads(text_data)
        # message = text_data_json['msg']
        # Send message to room group
        await self.channel_layer.group_send(
            self.watch_name,
            {
                'type': 'chat_message',
                'message': message
            }
        )

    # Receive message from room group
    async def chat_message(self, event):
        message = event['message']
        if self.level == 'all':
            await updateProgram(message)

        programs = [
            dict(name="JCT_1", host="fpis-kbsiml35", pid=1665, modules=[
                dict(name="module_1", order=0, fails=1, trades=2),
                dict(name="module_2", currGMV=3, maxGMV=4),
                dict(name="module_3", startTime=5)]),
            dict(name="JCT_2", host="fpis-kbsiml14", pid=1666, modules=[
                dict(name="module_1", order=6, fails=7, trades=8),
                dict(name="module_2", currGMV=9, maxGMV=10),
                dict(name="module_3", startTime=11)]),
            dict(name="JCT_3", host="fpis-kbsiml35", pid=1667, modules=[
                dict(name="module_1", order=6, fails=7, trades=8),
                dict(name="module_2", currGMV=9, maxGMV=10),
                dict(name="module_3", startTime=11)]),
            dict(name="JCT_4", host="fpis-kbsiml14", pid=1668, modules=[
                dict(name="module_1", order=12, fails=13, trades=14),
                dict(name="module_2", currGMV=15, maxGMV=16),
                dict(name="module_3", startTime=17)]),
            dict(name="JCT_5", host="fpis-kbsiml35", pid=1669, modules=[
                dict(name="module_1", order=18, fails=19, trades=20),
                dict(name="module_2", currGMV=21, maxGMV=22),
                dict(name="module_3", startTime=23)]),
            dict(name="JCT_6", host="fpis-kbsiml14", pid=1670, modules=[
                dict(name="module_1", order=24, fails=25, trades=26),
                dict(name="module_2", currGMV=27, maxGMV=28),
                dict(name="module_3", startTime=29)]),
            dict(name="JCT_7", host="fpis-kbsiml35", pid=1671, modules=[
                dict(name="module_1", order=30, fails=31, trades=32),
                dict(name="module_2", currGMV=33, maxGMV=34),
                dict(name="module_3", startTime=35)]),
            dict(name="JCT_8", host="fpis-kbsiml14", pid=1672, modules=[
                dict(name="module_1", order=36, fails=37, trades=38),
                dict(name="module_2", currGMV=39, maxGMV=40),
                dict(name="module_3", startTime=41)]),

            dict(name="JPRISK_1", host="fpis-kbsiml35", pid=1673, modules=[
                dict(name="module_1", order=42, fails=43, trades=44),
                dict(name="module_2", currGMV=45, maxGMV=46),
                dict(name="module_3", startTime=47)]),
            dict(name="JPRISK_2", host="fpis-kbsiml14", pid=1673, modules=[
                dict(name="module_1", order=48, fails=49, trades=50),
                dict(name="module_2", currGMV=51, maxGMV=52),
                dict(name="module_3", startTime=53)]),
            dict(name="JPRISK_3", host="fpis-kbsiml35", pid=1674, modules=[
                dict(name="module_1", order=54, fails=55, trades=56),
                dict(name="module_2", currGMV=57, maxGMV=58),
                dict(name="module_3", startTime=59)]),
            dict(name="JPRISK_4", host="fpis-kbsiml14", pid=1675, modules=[
                dict(name="module_1", order=60, fails=61, trades=62),
                dict(name="module_2", currGMV=63, maxGMV=64),
                dict(name="module_3", startTime=65)]),
            dict(name="JPRISK_5", host="fpis-kbsiml35", pid=1676, modules=[
                dict(name="module_1", order=66, fails=67, trades=68),
                dict(name="module_2", currGMV=69, maxGMV=70),
                dict(name="module_3", startTime=71)]),
            dict(name="JPRISK_6", host="fpis-kbsiml14", pid=1677, modules=[
                dict(name="module_1", order=72, fails=73, trades=74),
                dict(name="module_2", currGMV=75, maxGMV=76),
                dict(name="module_3", startTime=77)]),
            dict(name="JPRISK_7", host="fpis-kbsiml35", pid=1678, modules=[
                dict(name="module_1", order=78, fails=79, trades=80),
                dict(name="module_2", currGMV=81, maxGMV=82),
                dict(name="module_3", startTime=83)]),
            dict(name="JPRISK_8", host="fpis-kbsiml14", pid=1679, modules=[
                dict(name="module_1", order=84, fails=85, trades=86),
                dict(name="module_2", currGMV=87, maxGMV=88),
                dict(name="module_3", startTime=89)]),

            dict(pg="JPAU_1", host="fpis-kbsiml35", pid=1673, modules=[
                dict(name="module_1", order=42, fails=43, trades=44),
                    dict(name="module_2", currGMV=45, maxGMV=46),
                    dict(name="module_3", startTime=47)]),
            dict(name="JPAU_2", host="fpis-kbsiml14", pid=1673, modules=[
                dict(name="module_1", order=48, fails=49, trades=50),
                dict(name="module_2", currGMV=51, maxGMV=52),
                dict(name="module_3", startTime=53)]),
            dict(name="JPAU_3", host="fpis-kbsiml35", pid=1674, modules=[
                dict(name="module_1", order=54, fails=55, trades=56),
                dict(name="module_2", currGMV=57, maxGMV=58),
                dict(name="module_3", startTime=59)]),
            dict(name="JPAU_4", host="fpis-kbsiml14", pid=1675, modules=[
                dict(name="module_1", order=60, fails=61, trades=62),
                dict(name="module_2", currGMV=63, maxGMV=64),
                dict(name="module_3", startTime=65)]),
            dict(name="JPAU_5", host="fpis-kbsiml35", pid=1676, modules=[
                dict(name="module_1", order=66, fails=67, trades=68),
                dict(name="module_2", currGMV=69, maxGMV=70),
                dict(name="module_3", startTime=71)]),
            dict(name="JPAU_6", host="fpis-kbsiml14", pid=1677, modules=[
                dict(name="module_1", order=72, fails=73, trades=74),
                dict(name="module_2", currGMV=75, maxGMV=76),
                dict(name="module_3", startTime=77)]),
            dict(name="JPAU_7", host="fpis-kbsiml35", pid=1678, modules=[
                dict(name="module_1", order=78, fails=79, trades=80),
                dict(name="module_2", currGMV=81, maxGMV=82),
                dict(name="module_3", startTime=83)]),
            dict(name="JPAU_8", host="fpis-kbsiml14", pid=1679, modules=[
                dict(name="module_1", order=84, fails=85, trades=86),
                dict(name="module_2", currGMV=87, maxGMV=88),
                dict(name="module_3", startTime=89)]),

            dict(name="JCHEDG_1", host="fpis-kbsiml35", pid=1665, modules=[
                dict(name="module_1", order=0, fails=1, trades=2),
                dict(name="module_2", currGMV=3, maxGMV=4),
                dict(name="module_3", startTime=5)]),
            dict(name="JCHEDG_2", host="fpis-kbsiml14", pid=1666, modules=[
                dict(name="module_1", order=6, fails=7, trades=8),
                dict(name="module_2", currGMV=9, maxGMV=10),
                dict(name="module_3", startTime=11)]),
            dict(name="JCHEDG_3", host="fpis-kbsiml35", pid=1667, modules=[
                dict(name="module_1", order=6, fails=7, trades=8),
                dict(name="module_2", currGMV=9, maxGMV=10),
                dict(name="module_3", startTime=11)]),
            dict(name="JCHEDG_4", host="fpis-kbsiml14", pid=1668, modules=[
                dict(name="module_1", order=12, fails=13, trades=14),
                dict(name="module_2", currGMV=15, maxGMV=16),
                dict(name="module_3", startTime=17)]),
            dict(name="JCHEDG_5", host="fpis-kbsiml35", pid=1669, modules=[
                dict(name="module_1", order=18, fails=19, trades=20),
                dict(name="module_2", currGMV=21, maxGMV=22),
                dict(name="module_3", startTime=23)]),
            dict(name="JCHEDG_6", host="fpis-kbsiml14", pid=1670, modules=[
                dict(name="module_1", order=24, fails=25, trades=26),
                dict(name="module_2", currGMV=27, maxGMV=28),
                dict(name="module_3", startTime=29)]),
            dict(name="JCHEDG_7", host="fpis-kbsiml35", pid=1671, modules=[
                dict(name="module_1", order=30, fails=31, trades=32),
                dict(name="module_2", currGMV=33, maxGMV=34),
                dict(name="module_3", startTime=35)]),
            dict(name="JCHEDG_8", host="fpis-kbsiml14", pid=1672, modules=[
                dict(name="module_1", order=36, fails=37, trades=38),
                dict(name="module_2", currGMV=39, maxGMV=40),
                dict(name="module_3", startTime=41)]),
        ]

        grouped = [
            dict(group="JCT", programs=[0, 1, 2, 3, 4, 5, 6, 7]),
            dict(group="JPRISK", programs=[8, 9, 10, 11, 12, 13, 14, 15]),
            dict(group="JPAU", programs=[16, 17, 18, 19, 20, 21, 22, 23]),
            dict(group="JCHEDG", programs=[24, 25, 26, 27, 28, 29, 30, 31]),
        ]

        # dict(pgInfo=dict(pg="JPRISK_2", host="fpis-kbsiml35", pid=121083),
        #      modInfo=dict(name='gwm', orders=0, fails=0,
        #                   trades=0)),
        # {
        #     'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
        #     'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
        #     'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
        #     'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
        # },
        # {
        #     'pgInfo': {'pg': "JCTRISK_2", 'host': "fpis-kbsiml14", 'pid': 1221},
        #     'modInfo': {'name': 'JCTRISK_2', 'type': 'PROGRAM', 'startTime': 1652946619}
        # },
        # {
        #     'pgInfo': {'pg': "JCTRISK_1", 'host': "fpis-kbsiml14", 'pid': 1200},
        #     'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3014, 'engaged': 3014}
        # },
        # {
        #     'pgInfo': {'pg': 'JCTRMM_1', 'host': 'fpis-kbsiml14', 'pid': 1299},
        #     'modInfo': {'name': 'rmm', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3117, 'engaged': 3117}
        # },
        # {
        #     'pgInfo': {'pg': 'JCT_4', 'host': 'fpis-kbsiml14', 'pid': 1089},
        #     'modInfo': {'name': 'LGBM_00_5m', 'type': 'LGBM', 'priority': 200}
        # },
        # {
        #     'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
        #     'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
        # },
        # {
        #     'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
        #     'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
        #     'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
        #     'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
        # },
        # {
        #     'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
        #     'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
        # },
        # {
        #     'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
        #     'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
        #     'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
        #     'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
        # },
        # {
        #     'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
        #     'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
        # },
        # {
        #     'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
        #     'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
        #     'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
        #     'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
        # },
        # {
        #     'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
        #     'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
        #     'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
        #     'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
        # },
        # {
        #     'pgInfo': {'pg': "JCTRISK_2", 'host': "fpis-kbsiml14", 'pid': 1221},
        #     'modInfo': {'name': 'JCTRISK_2', 'type': 'PROGRAM', 'startTime': 1652946619}
        # },
        # {
        #     'pgInfo': {'pg': "JCTRISK_1", 'host': "fpis-kbsiml14", 'pid': 1200},
        #     'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3014, 'engaged': 3014}
        # },
        # {
        #     'pgInfo': {'pg': 'JCTRMM_1', 'host': 'fpis-kbsiml14', 'pid': 1299},
        #     'modInfo': {'name': 'rmm', 'currGMV': 0, 'maxGMV': 0, 'symbols': 3117, 'engaged': 3117}
        # },
        # {
        #     'pgInfo': {'pg': 'JCT_4', 'host': 'fpis-kbsiml14', 'pid': 1089},
        #     'modInfo': {'name': 'LGBM_00_5m', 'type': 'LGBM', 'priority': 200}
        # },
        # {
        #     'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
        #     'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
        # },
        # {
        #     'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
        #     'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
        #     'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
        #     'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
        # },
        # {
        #     'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
        #     'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
        # },
        # {
        #     'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
        #     'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
        #     'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
        #     'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
        # },
        # {
        #     'pgInfo': {'pg': "JPRISK_2", 'host': "fpis-kbsiml35", 'pid': 121083},
        #     'modInfo': {'name': 'gwm', 'orders': 0, 'fails': 0, 'trades': 0}
        # },
        # {
        #     'pgInfo': {'pg': "TEST_abcdefgh", "host": "", "pid": "" },
        # },
        # {
        #     'pgInfo': {'pg': "JPAU_2", 'host': "fpis-kbsiml35", 'pid': 120830},
        #     'modInfo': {'name': "gwm", 'orders': 91, 'fails': 303, 'trades': 137}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_1', 'host': 'fpis-kbsiml35', 'pid': 121242},
        #     'modInfo': {'name': 'JPHEDG_1', 'type': 'PROGRAM', 'startTime': 1652915433}
        # },
        # {
        #     'pgInfo': {'pg': 'JPHEDG_2', 'host': 'fpis-kbsiml35', 'pid': 121064},
        #     'modInfo': {'name': 'dummytrading', 'currGMV': 0, 'maxGMV': 0, 'symbols': 1, 'engaged': 1}
        # }

        logs = [
            {"pg": "JPHEDG_1", 'timestamp': datetime.datetime.now().strftime(
                "%Y/%m/%d %H:%M:%S.%f"), "msg": "[JPHEDG_1]: Everything is fine.", "level": "success"},
            {"pg": "JPHEDG_2", 'timestamp': datetime.datetime.now().strftime(
                "%Y/%m/%d %H:%M:%S.%f"), "msg": "[JPHEDG_2]: Everything is fine.", "level": "success"},
            {"pg": "JPHEDG_3", 'timestamp': datetime.datetime.now().strftime(
                "%Y/%m/%d %H:%M:%S.%f"), "msg": "[JPHEDG_3]: Something is wrong.", "level": "warning"},
            {"pg": "JCT_1", 'timestamp': datetime.datetime.now().strftime(
                "%Y/%m/%d %H:%M:%S.%f"), "msg": "[JCT_1]: Everything is fine", "level": "success"},
            {"pg": "JCT_2", 'timestamp': datetime.datetime.now().strftime(
                "%Y/%m/%d %H:%M:%S.%f"), "msg": "[JCT_2]: Not responding, please reboot.", "level": "alert"},
            {"pg": "JCT_3", 'timestamp': datetime.datetime.now().strftime(
                "%Y/%m/%d %H:%M:%S.%f"), "msg": "[JCT_3]: Not responding, please reboot.", "level": "alert"},
            {"pg": "JPAU_1", 'timestamp': datetime.datetime.now().strftime(
                "%Y/%m/%d %H:%M:%S.%f"), "msg": "[JPAU_1]: Reboot success.", "level": "success"},
            {"pg": "JPAU_2", 'timestamp': datetime.datetime.now().strftime(
                "%Y/%m/%d %H:%M:%S.%f"), "msg": "[JPAU_2]: Bootstraping, please wait.", "level": "warning"}
        ]
        result = dict(ResponseInfo.GeneralGetSuccess.value,
                      data=dict(program=message))
        # data=dict(programs=programs, grouped=grouped, logs=logs))

        # Send message to WebSocket
        # await self.send(text_data=json.dumps({
        #     'message': message
        # }))

        await self.send(text_data=json.dumps(result))
