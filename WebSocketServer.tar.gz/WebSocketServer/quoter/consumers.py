from cgitb import text
import json
import subprocess
import time
import urllib
from asgiref.sync import sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer
from common.responseinfo import ResponseInfo
from django.db.models import Q

from quoter.serializer import *
from .models import *


@sync_to_async
def getAllProgramsForQuery(project_names, host_names, program_names):
    programs = Program.objects.filter(Q(name__in=program_names) | Q(
        project__name__in=project_names) | Q(host__name__in=host_names))
    logs = Log.objects.filter(Q(program__name__in=program_names) | Q(
        program__project__name__in=project_names) | Q(program__host__name__in=host_names))
    # programs = Program.objects.select_related("host", "project").filter(
    #     Q(name__in=programs) | Q(host__name__in=hosts) | Q(project__name__in=projects))
    # logs = Log.objects.select_related("program__host", "program__project").filter(
    #     Q(program__host__name__in=hosts) | Q(program__project__name__in=projects))

    if logs.count() > 0:
        logs = list(logs.order_by('ctime')[
                    max(0, logs.count() - 10):logs.count()])
        logs = LogSerializer(logs, many=True).data
    else:
        logs = None

    programs_info = []
    for program in programs:
        modules = Module.objects.select_related('program').filter(
            program=program).order_by('-ctime').first()

        sentModule = {}
        if modules is not None:
            modules = json.loads(modules.info)
            for module in modules:
                sentModule[module["name"]] = module

        programs_info.append(
            {
                'program_id': program.id,
                'program_name': program.name,
                'project_id': program.project.id,
                'project_name': program.project.name,
                'host_id': program.host.id,
                'host_name': program.host.name,
                'pid': program.pid,
                'reboots': program.reboots,
                'startTime': program.startTime,
                'updateTime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),
                'modules': sentModule
            }
        )

    projects = ProjectSerializer(list(Project.objects.all()), many=True).data
    hosts = HostSerializer(list(Host.objects.all()), many=True).data
    if logs is not None:
        return dict(projects=projects, hosts=hosts, programs=programs_info, logs=logs)
    else:
        return dict(projects=projects, hosts=hosts, programs=programs_info)


def subprocess_popen(statement):
    p = subprocess.Popen(statement, shell=True, stdout=subprocess.PIPE)
    while p.poll() is None:
        # if p.wait() != 0:
        # re = p.stderr.readlines()
        # else:
        re = p.stdout.readlines()
        result = ''
        for i in range(len(re)):
            result += re[i].decode('utf-8')
        return result


class CommandConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        if self.scope['user'].is_anonymous or not self.scope['user'].is_authenticated:
            await self.close()
        else:
            await self.accept()

    async def receive(self, text_data=None, bytes_data=None):
        print('received command:', text_data)
        if isinstance(text_data, str):
            text_data = json.loads(text_data)
        await self.send(text_data=subprocess_popen(text_data['message']))


class QuoterConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        print("Connect....", self.scope)
        if self.scope['user'].is_anonymous or not self.scope['user'].is_authenticated:
            await self.close()

        self.project_names = []
        self.host_names = []
        self.program_names = []
        self.group_name = ''

        try:
            # vue websocket data sent via proxy will change
            # '"' to '%22', '{' to '%7B', '}' to '%7D'
            # only for development which actually uses proxy
            query = json.loads(urllib.parse.unquote(
                self.scope['query_string'], encoding='utf-8'))

            self.project_names = sorted(
                query['projects']) if 'projects' in query else []
            self.host_names = sorted(query['hosts']) if 'hosts' in query else []
            self.program_names = sorted(
                query['programs']) if 'programs' in query else []
            for project in self.project_names:
                self.group_name += project
            for host in self.host_names:
                self.group_name += host
            for program in self.program_names:
                self.group_name += program
        except Exception as e:
            print(e)
        self.group_name = str(hash(self.group_name))

        # Join group
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.channel_layer.group_add("notification", self.channel_name)

        await self.accept()

        print('channel for:', self.project_names, ', ',
              self.host_names, ', ', self.program_names)

        await self.send(text_data=json.dumps(
            dict(ResponseInfo.GeneralGetSuccess.value,
                 data=await getAllProgramsForQuery(self.project_names, self.host_names, self.program_names))
        ))

    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name

        )

    # Receive message from WebSocket
    async def receive(self, text_data):
        if isinstance(text_data, str):
            text_data = json.loads(text_data)
        print('receive:', text_data, isinstance(text, dict))
        # Send message to group
        await self.channel_layer.group_send(
            self.group_name,
            {
                'type': 'group_send',
                'message': text_data['message']
            }
        )

    # Receive message from group
    async def group_send(self, event):
        if not await self.needToSend(event['message']):
            print('not sending...', self.host_names, '--->', self.project_names)
            return
        print('sending...')
        await self.send(text_data=json.dumps(event['message']))

    @sync_to_async
    def needToSend(self, message):
        program = Program.objects.filter(
            id=message['data']['program']['program_id']).filter(Q(project__name__in=self.project_names) | Q(
            host__name__in=self.host_names) | Q(name__in=self.program_names))
        return program.count() > 0
