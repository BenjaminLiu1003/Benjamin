import asyncio
import datetime
import json
from multiprocessing import managers
from this import d
from unittest import case
from asgiref.sync import sync_to_async, async_to_sync
from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer
from common.responseinfo import ResponseInfo
from django.core import serializers

from quoter.serializer import *
from .models import *


@sync_to_async
def updateProgram(message):
    group = Group.objects.get_or_none(name=message['group'])
    if group is None:
        return

    program = Program.objects.get_or_none(name=message['name'])
    if program is None:
        return
    program.update({
        'group': group, 'host': message['host'], 'pid': message['pid']
    })
    message['id'] = program.id
    message['group'] = group.id

    for module in message['modules']:
        if module['name'] == 'log':
            log = Log.objects.addLog(program, module['text'], module['level'])
            module['ctime'] = LogSerializer(log).data['ctime']
        elif module['name'] == 'component1':
            Component1.objects.addComponent1(
                program, module['orders'], module['trades'], module['fails'])
        elif module['name'] == 'component2':
            Component2.objects.addComponent2(
                program, module['currGMV'], module['maxGMV'])
        elif module['name'] == 'component3':
            Component3.objects.addComponent3(
                program, module['symbols'], module['engaged'])


@sync_to_async
def getAllProgramsForStrategy(strategy):
    groups = GroupSerializer(list(Group.objects.all()), many=True).data
    hosts = HostSerializer(list(Host.objects.all()), many=True).data

    programs = list(Program.objects.select_related("group").filter(group__name=strategy))
    programs = ProgramSerializer(programs, many=True).data

    logs = Log.objects.select_related(
        "program__group").filter(program__group__name=strategy)
    if logs.count() > 0:
        logs = list(logs.order_by('ctime')[
                    max(0, logs.count() - 10):logs.count()])
        logs = LogSerializer(logs, many=True).data
    else:
        logs = None

    for program in programs:
        modules = []
        component1 = Component1.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component1 is not None:
            modules.append(dict(name="component1", orders=component1.orders,
                           trades=component1.trades, fails=component1.fails))
        else:
            modules.append(dict(name="component1"))

        component2 = Component2.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component2 is not None:
            modules.append(
                dict(name="component2", currGMV=component2.currGMV, maxGMV=component2.maxGMV))
        else:
            modules.append(dict(name="component2"))

        component3 = Component3.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component3 is not None:
            modules.append(
                dict(name="component3", symbols=component3.symbols, engaged=component3.engaged))
        else:
            modules.append(dict(name="component3"))

        program['modules'] = modules

    if logs is not None:
        return dict(groups=groups, hosts=hosts, programs=programs, logs=logs)
    else:
        return dict(groups=groups, hosts=hosts, programs=programs)


@sync_to_async
def getAllProgramsForHost(host):
    groups = GroupSerializer(list(Group.objects.all()), many=True).data
    hosts = HostSerializer(list(Host.objects.all()), many=True).data

    programs = list(Program.objects.select_related("host").filter(host__name=host))
    programs = ProgramSerializer(programs, many=True).data

    logs = Log.objects.select_related("program__host").filter(program__host__name=host)
    if logs.count() > 0:
        logs = list(logs.order_by('ctime')[
                    max(0, logs.count() - 10):logs.count()])
        logs = LogSerializer(logs, many=True).data
    else:
        logs = None

    for program in programs:
        modules = []
        component1 = Component1.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component1 is not None:
            modules.append(dict(name="component1", orders=component1.orders,
                           trades=component1.trades, fails=component1.fails))
        else:
            modules.append(dict(name="component1"))

        component2 = Component2.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component2 is not None:
            modules.append(
                dict(name="component2", currGMV=component2.currGMV, maxGMV=component2.maxGMV))
        else:
            modules.append(dict(name="component2"))

        component3 = Component3.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component3 is not None:
            modules.append(
                dict(name="component3", symbols=component3.symbols, engaged=component3.engaged))
        else:
            modules.append(dict(name="component3"))

        program['modules'] = modules

    if logs is not None:
        return dict(groups=groups, hosts=hosts, programs=programs, logs=logs)
    else:
        return dict(groups=groups, hosts=hosts, programs=programs)


@sync_to_async
def getAllPrograms():
    groups = GroupSerializer(list(Group.objects.all()), many=True).data
    hosts = GroupSerializer(list(Host.objects.all()), many=True).data

    programs = list(Program.objects.all())
    programs = ProgramSerializer(programs, many=True).data

    logsNum = Log.objects.count()
    if logsNum > 0:
        logs = list(Log.objects.order_by('ctime')[
                    max(0, logsNum - 10):logsNum])
        logs = LogSerializer(logs, many=True).data
    else:
        logs = None

    for program in programs:
        modules = []
        component1 = Component1.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component1 is not None:
            modules.append(dict(name="component1", orders=component1.orders,
                           trades=component1.trades, fails=component1.fails))
        else:
            modules.append(dict(name="component1"))

        component2 = Component2.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component2 is not None:
            modules.append(
                dict(name="component2", currGMV=component2.currGMV, maxGMV=component2.maxGMV))
        else:
            modules.append(dict(name="component2"))

        component3 = Component3.objects.select_related('program').filter(
            program__name=program['name']).order_by('-ctime').first()
        if component3 is not None:
            modules.append(
                dict(name="component3", symbols=component3.symbols, engaged=component3.engaged))
        else:
            modules.append(dict(name="component3"))

        program['modules'] = modules

    if logs is not None:
        return dict(groups=groups, hosts=hosts, programs=programs, logs=logs)
    else:
        return dict(groups=groups, hosts=hosts, programs=programs)


class QuoterConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        # self.room_name = self.scope['url_route']['kwargs']['room_name']
        # self.room_group_name = 'chat_%s' % self.room_name

        # self.level = self.scope['query_string']['level'] // unfinished here, need to split b'level=all&key=all'
        # self.key = self.scope['query_string']['key']
        # self.watch_name = self.level + '_' + self.key

        print("Connect....", self.scope)
        print("Channel_name....", self.channel_name)
        print("Channel_layer...", self.channel_layer)
        print("User name......", self.scope["user"])
        self.level = self.scope['url_route']['kwargs']['level']
        self.key = self.scope['url_route']['kwargs']['key']

        # self.scope['url_route']['kwargs']['watch_name']
        self.watch_name = self.level + '_' + self.key

        # Join room group
        await self.channel_layer.group_add(
            self.watch_name,
            self.channel_name
        )
        await self.channel_layer.group_add(
            "notification",
            self.channel_name
        )

        await self.accept()

        # loopRun()
        # programs = sync_to_async(serializers.serialize)("json", Program.objects.all())
        # programs = await database_sync_to_async(list)(Program.objects.all())
        # programs = await database_sync_to_async(Program.objects.all)()
        # print(programs)
        # programs = await sync_to_async(ProgramSerializer)(programs, many=True)
        # programs = await getAllPrograms()# await programs.data
        # print(programs)
        # print(programs)
        # programs = await ProgramSerializer(programs, many=True)
        # programs = programs.data
        # programs = await database_sync_to_async(Program.objects.all)()
        # await self.send(text_data=json.dumps(programs))
        # await self.send(text_data=json.dumps(programs))

        if self.level == 'host':
            await self.send(text_data=json.dumps(dict(ResponseInfo.GeneralGetSuccess.value,
                                                      data=await getAllProgramsForHost(self.key))))
        elif self.level == 'strategy':
            await self.send(text_data=json.dumps(dict(ResponseInfo.GeneralGetSuccess.value,
                                                      data=await getAllProgramsForStrategy(self.key))))
        else:
            await self.send(text_data=json.dumps(dict(ResponseInfo.GeneralGetSuccess.value,
                                                      data=await getAllPrograms()
                                                      # data=serializers.serialize(
                                                      #     'json', programs, fields=('name', 'pid'))
                                                      # data=serializers.serialize(
                                                      #     'json', programs)
                                                      )))

        # await self.send(text_data=json.dumps({
        #   'type': 'first',
        #   'message1': "success",
        #   "testkey": 'TestValue'
        # }))

    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.watch_name,
            self.channel_name

        )

    # Receive message from WebSocket
    async def receive(self, text_data):
        message = text_data['message']
        print('receive:', self.watch_name, "---->", self.channel_name)
        print(message)

        # text_data_json = json.loads(text_data)
        # message = text_data_json['msg']
        # Send message to room group
        await self.channel_layer.group_send(
            self.watch_name,
            {
                'type': 'chat_message',
                'message': message
            }
        )

    @sync_to_async
    def needToSend(self, message):
        if self.level == 'host':
            program = Program.objects.select_related("host").filter(
                name=message['data']['program']['name'],
                host__name=self.key)
            if len(program) == 0:
                return False
        elif self.level == 'strategy':
            program = Program.objects.select_related("group").filter(
                name=message['data']['program']['name'],
                group__name=self.key)
            if len(program) == 0:
              return False

        return True

    # Receive message from room group
    async def group_send_program(self, event):
        message = event['message']
        print('chat_message:', self.watch_name, '--->', self.channel_name)
        print(message)

        sending = await self.needToSend(message)
        if not sending:
            print('Not sending to.....', self.watch_name)
            return
        # if self.level == 'all':
        #     await updateProgram(message)

        # result = dict(ResponseInfo.GeneralGetSuccess.value,
        #               data=dict(program=message))
        # data=dict(programs=programs, grouped=grouped, logs=logs))

        # Send message to WebSocket
        # await self.send(text_data=json.dumps({
        #     'message': message
        # }))

        await self.send(text_data=json.dumps(message))
