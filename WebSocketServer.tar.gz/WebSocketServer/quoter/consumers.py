import asyncio
import datetime
import json, time
from multiprocessing import managers
from this import d
from unittest import case
from asgiref.sync import sync_to_async, async_to_sync
from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer
from common.responseinfo import ResponseInfo
from django.core import serializers

from quoter.serializer import *
from .models import *


@sync_to_async
def updateProgram(message):
    group = Project.objects.get_or_none(name=message['group'])
    if group is None:
        return

    program = Program.objects.get_or_none(name=message['name'])
    if program is None:
        return
    program.update({
        'group': group, 'host': message['host'], 'pid': message['pid']
    })
    message['id'] = program.id
    message['group'] = group.id

    # for module in message['modules']:
    #     if module['name'] == 'log':
    #         log = Log.objects.addLog(program, module['text'], module['level'])
    #         module['ctime'] = LogSerializer(log).data['ctime']
    #     elif module['name'] == 'component1':
    #         Component1.objects.addComponent1(
    #             program, module['orders'], module['trades'], module['fails'])
    #     elif module['name'] == 'component2':
    #         Component2.objects.addComponent2(
    #             program, module['currGMV'], module['maxGMV'])
    #     elif module['name'] == 'component3':
    #         Component3.objects.addComponent3(
    #             program, module['symbols'], module['engaged'])


@sync_to_async
def getAllProgramsForStrategy(strategy):
    groups = ProjectSerializer(list(Project.objects.all()), many=True).data
    hosts = HostSerializer(list(Host.objects.all()), many=True).data

    programs = list(Program.objects.select_related(
        "group").filter(group__name=strategy))
    programs = ProgramSerializer(programs, many=True).data

    logs = Log.objects.select_related(
        "program__group").filter(program__group__name=strategy)
    if logs.count() > 0:
        logs = list(logs.order_by('ctime')[
                    max(0, logs.count() - 10):logs.count()])
        logs = LogSerializer(logs, many=True).data
    else:
        logs = None

    programsInfo = []
    for program in programs:
        modules = Module.objects.select_related('program').filter(
            program=program).order_by('-ctime').first()

        sentModule = {}
        if modules is not None:
            modules = json.loads(modules.info)
            for module in modules:
                sentModule[module["name"]] = module

        programsInfo.append(
            {
                'program_id': program.id,
                'program': program.name,
                'project_id': program.project.id,
                'project': program.project.name,
                'host_id': program.host.id,
                'host': program.host.name,
                'pid': program.pid,
                'reboots': program.reboots,
                'startTime': program.startTime,
                'modules': sentModule,
            }
        )
    # for program in programs:
    #     modules = []
    #     component1 = Component1.objects.select_related('program').filter(
    #         program__name=program['name']).order_by('-ctime').first()
    #     if component1 is not None:
    #         modules.append(dict(name="component1", orders=component1.orders,
    #                        trades=component1.trades, fails=component1.fails))
    #     else:
    #         modules.append(dict(name="component1"))

    #     component2 = Component2.objects.select_related('program').filter(
    #         program__name=program['name']).order_by('-ctime').first()
    #     if component2 is not None:
    #         modules.append(
    #             dict(name="component2", currGMV=component2.currGMV, maxGMV=component2.maxGMV))
    #     else:
    #         modules.append(dict(name="component2"))

    #     component3 = Component3.objects.select_related('program').filter(
    #         program__name=program['name']).order_by('-ctime').first()
    #     if component3 is not None:
    #         modules.append(
    #             dict(name="component3", symbols=component3.symbols, engaged=component3.engaged))
    #     else:
    #         modules.append(dict(name="component3"))

    #     program['modules'] = modules

    if logs is not None:
        return dict(groups=groups, hosts=hosts, programs=programsInfo, logs=logs)
    else:
        return dict(groups=groups, hosts=hosts, programs=programsInfo)


@sync_to_async
def getAllProgramsForQuery(hosts, projects):
    from django.db.models import Q
    programs = Program.objects.select_related("host", "project").filter(
        Q(host__name__in=hosts) | Q(project__name__in=projects))
    logs = Log.objects.select_related("program__host", "program__project").filter(
        Q(program__host__name__in=hosts) | Q(program__project__name__in=projects))
    if logs.count() > 0:
        logs = list(logs.order_by('ctime')[
                    max(0, logs.count() - 10):logs.count()])
        logs = LogSerializer(logs, many=True).data
    else:
        logs = None

    programsInfo = []
    for program in programs:
        modules = Module.objects.select_related('program').filter(
            program=program).order_by('-ctime').first()

        sentModule = {}
        if modules is not None:
            modules = json.loads(modules.info)
            for module in modules:
                sentModule[module["name"]] = module

        programsInfo.append(
            {
                'program_id': program.id,
                'program': program.name,
                'project_id': program.project.id,
                'project': program.project.name,
                'host_id': program.host.id,
                'host': program.host.name,
                'pid': program.pid,
                'reboots': program.reboots,
                'startTime': program.startTime,
                'updateTime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),
                'modules': sentModule
            }
        )
    
    projects1 = ProjectSerializer(list(Project.objects.all()), many=True).data
    hosts1 = HostSerializer(list(Host.objects.all()), many=True).data
    if logs is not None:
        return dict(projects=projects1, hosts=hosts1, programs=programsInfo, logs=logs)
    else:
        return dict(projects=projects1, hosts=hosts1, programs=programsInfo)


@sync_to_async
def getAllProgramsForHost(host):
    groups = ProjectSerializer(list(Project.objects.all()), many=True).data
    hosts = HostSerializer(list(Host.objects.all()), many=True).data

    programs = list(Program.objects.select_related(
        "host").filter(host__name=host))
    # programs = ProgramSerializer(programs, many=True).data

    logs = Log.objects.select_related(
        "program__host").filter(program__host__name=host)
    if logs.count() > 0:
        logs = list(logs.order_by('ctime')[
                    max(0, logs.count() - 10):logs.count()])
        logs = LogSerializer(logs, many=True).data
    else:
        logs = None

    programsInfo = []
    for program in programs:
        modules = Module.objects.select_related('program').filter(
            program=program).order_by('-ctime').first()

        sentModule = {}
        if modules is not None:
            modules = json.loads(modules.info)
            for module in modules:
                sentModule[module["name"]] = module

        programsInfo.append(
            {
                'program_id': program.id,
                'program': program.name,
                'project_id': program.project.id,
                'project': program.project.name,
                'host_id': program.host.id,
                'host': program.host.name,
                'pid': program.pid,
                'reboots': program.reboots,
                'startTime': program.startTime,
                'modules': sentModule
            }
        )
    # for program in programs:
    #     modules = []
    #     component1 = Component1.objects.select_related('program').filter(
    #         program__name=program['name']).order_by('-ctime').first()
    #     if component1 is not None:
    #         modules.append(dict(name="component1", orders=component1.orders,
    #                        trades=component1.trades, fails=component1.fails))
    #     else:
    #         modules.append(dict(name="component1"))

    #     component2 = Component2.objects.select_related('program').filter(
    #         program__name=program['name']).order_by('-ctime').first()
    #     if component2 is not None:
    #         modules.append(
    #             dict(name="component2", currGMV=component2.currGMV, maxGMV=component2.maxGMV))
    #     else:
    #         modules.append(dict(name="component2"))

    #     component3 = Component3.objects.select_related('program').filter(
    #         program__name=program['name']).order_by('-ctime').first()
    #     if component3 is not None:
    #         modules.append(
    #             dict(name="component3", symbols=component3.symbols, engaged=component3.engaged))
    #     else:
    #         modules.append(dict(name="component3"))

    #     program['modules'] = modules

    if logs is not None:
        return dict(groups=groups, hosts=hosts, programs=programsInfo, logs=logs)
    else:
        return dict(groups=groups, hosts=hosts, programs=programsInfo)


@sync_to_async
def getAllPrograms():
    projects = ProjectSerializer(list(Project.objects.all()), many=True).data
    hosts = HostSerializer(list(Host.objects.all()), many=True).data

    programs = Program.objects.all()
    # programs = ProgramSerializer(list(programs), many=True).data

    logsNum = Log.objects.count()
    if logsNum > 0:
        logs = list(Log.objects.order_by('ctime')[
                    max(0, logsNum - 10):logsNum])
        logs = LogSerializer(logs, many=True).data
    else:
        logs = None

    programsInfo = []
    for program in programs:
        modules = Module.objects.select_related('program').filter(
            program=program).order_by('-ctime').first()

        sentModule = {}
        if modules is not None:
            modules = json.loads(modules.info)
            for module in modules:
                sentModule[module["name"]] = module

        programsInfo.append(
            {
                'program_id': program.id,
                'program': program.name,
                'project_id': program.project.id,
                'project': program.project.name,
                'host_id': program.host.id,
                'host': program.host.name,
                'pid': program.pid,
                'reboots': program.reboots,
                'startTime': program.startTime,
                'updateTime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),
                'modules': sentModule
            }
        )

        # modules = []
        # component1 = Component1.objects.select_related('program').filter(
        #     program__name=program['name']).order_by('-ctime').first()
        # if component1 is not None:
        #     modules.append(dict(name="component1", orders=component1.orders,
        #                    trades=component1.trades, fails=component1.fails))
        # else:
        #     modules.append(dict(name="component1"))

        # component2 = Component2.objects.select_related('program').filter(
        #     program__name=program['name']).order_by('-ctime').first()
        # if component2 is not None:
        #     modules.append(
        #         dict(name="component2", currGMV=component2.currGMV, maxGMV=component2.maxGMV))
        # else:
        #     modules.append(dict(name="component2"))

        # component3 = Component3.objects.select_related('program').filter(
        #     program__name=program['name']).order_by('-ctime').first()
        # if component3 is not None:
        #     modules.append(
        #         dict(name="component3", symbols=component3.symbols, engaged=component3.engaged))
        # else:
        #     modules.append(dict(name="component3"))

        # program['modules'] = modules

    if logs is not None:
        return dict(projects=projects, hosts=hosts, programs=programsInfo, logs=logs)
    else:
        return dict(projects=projects, hosts=hosts, programs=programsInfo)


class TypeCheck1:
    @staticmethod
    def validate(value):
        return isinstance(value, int) or (isinstance(value, str) and value is not "") or isinstance(value, bool) or isinstance(value, list) or isinstance(value, datetime) or isinstance(value, date)


class Filter1:
    @staticmethod
    def dict_filter(dict_in):
        result = {}
        for key, value in dict_in.items():
            if TypeCheck1.validate(value):
                result[key] = value
        return result


class QuoterConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        # self.room_name = self.scope['url_route']['kwargs']['room_name']
        # self.room_group_name = 'chat_%s' % self.room_name

        # self.level = self.scope['query_string']['level'] // unfinished here, need to split b'level=all&key=all'
        # self.key = self.scope['query_string']['key']
        # self.watch_name = self.level + '_' + self.key

        print("Connect....", self.scope)
        print("Channel_name....", self.channel_name)
        print("Channel_layer...", self.channel_layer)
        print("User name......", self.scope["user"])
        # self.level = self.scope['url_route']['kwargs']['level']
        # self.key = self.scope['url_route']['kwargs']['key']

        # self.scope['url_route']['kwargs']['watch_name']
        # self.watch_name = self.level + '_' + self.key
        query_string = str(self.scope['query_string'], 'utf-8')

        self.hosts = []
        self.projects = []

        if query_string == '':
            self.level = 'all'
            self.key = 'all'
            self.watch_name = self.level + '_' + self.key
        else:
            query_string = query_string.replace("%22", '"')
            query = json.loads(query_string)
            self.hosts_name = "hosts_"
            self.projects_name = "projects_"
            if 'hosts' in query:
                self.hosts = query['hosts']
                for host in self.hosts:
                    self.hosts_name += host + "_"
            if 'projects' in query:
                self.projects = query['projects']
                for project in self.projects:
                    self.projects_name += project + "_"

            self.watch_name = self.hosts_name + self.projects_name

        # Join room group
        await self.channel_layer.group_add(
            self.watch_name,
            self.channel_name
        )
        await self.channel_layer.group_add(
            "notification",
            self.channel_name
        )

        await self.accept()

        # loopRun()
        # programs = sync_to_async(serializers.serialize)("json", Program.objects.all())
        # programs = await database_sync_to_async(list)(Program.objects.all())
        # programs = await database_sync_to_async(Program.objects.all)()
        # print(programs)
        # programs = await sync_to_async(ProgramSerializer)(programs, many=True)
        # programs = await getAllPrograms()# await programs.data
        # print(programs)
        # print(programs)
        # programs = await ProgramSerializer(programs, many=True)
        # programs = programs.data
        # programs = await database_sync_to_async(Program.objects.all)()
        # await self.send(text_data=json.dumps(programs))
        # await self.send(text_data=json.dumps(programs))


        if len(self.hosts) or len(self.projects):
          await self.send(text_data=json.dumps(dict(ResponseInfo.GeneralGetSuccess.value,
                                               data=await getAllProgramsForQuery(self.hosts, self.projects))))
        # if self.level == 'host':
        #     await self.send(text_data=json.dumps(dict(ResponseInfo.GeneralGetSuccess.value,
        #                                               data=await getAllProgramsForHost(self.key))))
        # elif self.level == 'strategy':
        #     await self.send(text_data=json.dumps(dict(ResponseInfo.GeneralGetSuccess.value,
        #                                               data=await getAllProgramsForStrategy(self.key))))
        else:
            await self.send(text_data=json.dumps(dict(ResponseInfo.GeneralGetSuccess.value,
                                                      data=await getAllPrograms()
                                                      # data=serializers.serialize(
                                                      #     'json', programs, fields=('name', 'pid'))
                                                      # data=serializers.serialize(
                                                      #     'json', programs)
                                                      )))

        # await self.send(text_data=json.dumps({
        #   'type': 'first',
        #   'message1': "success",
        #   "testkey": 'TestValue'
        # }))

    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.watch_name,
            self.channel_name

        )

    # Receive message from WebSocket
    async def receive(self, text_data):
        message = text_data['message']
        print('receive:', self.watch_name, "---->", self.channel_name)
        print(message)

        # text_data_json = json.loads(text_data)
        # message = text_data_json['msg']
        # Send message to room group
        await self.channel_layer.group_send(
            self.watch_name,
            {
                'type': 'chat_message',
                'message': message
            }
        )

    @sync_to_async
    def needToSend(self, message):
        if len(self.hosts) > 0:
            program = Program.objects.select_related("host").filter(
                id=message["data"]["program"]["program_id"],
                host__name__in=self.hosts)
            if len(program):
                return True
        if len(self.projects) > 0:
            program = Program.objects.select_related("project").filter(
                id=message["data"]["program"]["program_id"],
                project__name__in=self.projects)
            if len(program):
                return True

        if len(self.hosts) or len(self.projects):
            return False

        # if self.level == 'host':
        #     program = Program.objects.select_related("host").filter(
        #         id=message['data']['program']['program_id'],
        #         host__name=self.key)
        #     if len(program) == 0:
        #         return False
        # elif self.level == 'strategy':
        #     program = Program.objects.select_related("project").filter(
        #         id=message['data']['program']['program_id'],
        #         project__name=self.key)
        #     if len(program) == 0:
        #         return False

        return True

    # Receive message from room group
    async def group_send_program(self, event):
        message = event['message']
        # print('chat_message:', self.watch_name, '--->', self.channel_name)
        # print(message)

        sending = await self.needToSend(message)
        if not sending:
            print('Not sending to.....', self.watch_name)
            return
        else:
          print("sent...")
        # if self.level == 'all':
        #     await updateProgram(message)

        # result = dict(ResponseInfo.GeneralGetSuccess.value,
        #               data=dict(program=message))
        # data=dict(programs=programs, grouped=grouped, logs=logs))

        # Send message to WebSocket
        # await self.send(text_data=json.dumps({
        #     'message': message
        # }))

        await self.send(text_data=json.dumps(message))
