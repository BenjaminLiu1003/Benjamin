import json
import time
import urllib
from asgiref.sync import sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer
from common.responseinfo import ResponseInfo
from django.db.models import Q

from quoter.serializer import *
from .models import *

@sync_to_async
def getAllProgramsForQuery(projects, hosts):
    programs = Program.objects.select_related("host", "project").filter(
        Q(host__name__in=hosts) | Q(project__name__in=projects))
    logs = Log.objects.select_related("program__host", "program__project").filter(
        Q(program__host__name__in=hosts) | Q(program__project__name__in=projects))

    if logs.count() > 0:
        logs = list(logs.order_by('ctime')[
                    max(0, logs.count() - 10):logs.count()])
        logs = LogSerializer(logs, many=True).data
    else:
        logs = None

    programsInfo = []
    for program in programs:
        modules = Module.objects.select_related('program').filter(
            program=program).order_by('-ctime').first()

        sentModule = {}
        if modules is not None:
            modules = json.loads(modules.info)
            for module in modules:
                sentModule[module["name"]] = module

        programsInfo.append(
            {
                'program_id': program.id,
                'program': program.name,
                'project_id': program.project.id,
                'project': program.project.name,
                'host_id': program.host.id,
                'host': program.host.name,
                'pid': program.pid,
                'reboots': program.reboots,
                'startTime': program.startTime,
                'updateTime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),
                'modules': sentModule
            }
        )

    projects1 = ProjectSerializer(list(Project.objects.all()), many=True).data
    hosts1 = HostSerializer(list(Host.objects.all()), many=True).data
    if logs is not None:
        return dict(projects=projects1, hosts=hosts1, programs=programsInfo, logs=logs)
    else:
        return dict(projects=projects1, hosts=hosts1, programs=programsInfo)


class QuoterConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        print("Connect....", self.scope)
        if self.scope['user'].is_anonymous or not self.scope['user'].is_authenticated:
            return

        self.hosts = []
        self.projects = []
        self.group_name = ''

        try:
            # vue websocket data sent via proxy will change
            # '"' to '%22', '{' to '%7B', '}' to '%7D'
            # only for development which actually uses proxy
            query = json.loads(urllib.parse.unquote(
                self.scope['query_string'], encoding='utf-8'))

            self.projects = sorted(query['projects'])
            self.hosts = sorted(query['hosts'])
            for project in self.projects:
                self.group_name += project
            for host in self.hosts:
                self.group_name += host
        except Exception as e:
            print(e)
        self.group_name = str(hash(self.group_name))

        # Join group
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.channel_layer.group_add("notification", self.channel_name)

        await self.accept()

        print(self.projects)
        print(self.hosts)
        
        await self.send(text_data=json.dumps(
            dict(ResponseInfo.GeneralGetSuccess.value,
                 data=await getAllProgramsForQuery(self.projects, self.hosts))
        ))

    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name

        )

    # Receive message from WebSocket
    async def receive(self, text_data):
        # Send message to group
        await self.channel_layer.group_send(
            self.group_name,
            {
                'type': 'group_send',
                'message': text_data['message']
            }
        )

    # Receive message from group
    async def group_send(self, event):
        if not await self.needToSend(event['message']):
            return

        await self.send(text_data=json.dumps(event['message']))

    @sync_to_async
    def needToSend(self, message):
        program = Program.objects.select_related('project', 'host').filter(
            id=message['data']['program']['program_id']).filter(Q(host__name__in=self.hosts) | Q(project__name__in=self.projects))
        return program.count() > 0