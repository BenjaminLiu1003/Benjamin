from django.urls import path

from . import consumers

websocket_urlpatterns = [
    path('v1', consumers.QuoterConsumer.as_asgi()),
    path('v1/command', consumers.CommandConsumer.as_asgi()),
]