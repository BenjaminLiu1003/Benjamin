from django.urls import re_path, path

from . import consumers

websocket_urlpatterns = [
    # re_path(r'ws/watch/(?P<room_name>\w+)/$', consumers.WatchConsumer.as_asgi()),
    # re_path(r'quoter/(?P<level>\w+)/(?P<key>\w+)$', consumers.QuoterConsumer.as_asgi()),
    path('quoter', consumers.QuoterConsumer.as_asgi()),
]