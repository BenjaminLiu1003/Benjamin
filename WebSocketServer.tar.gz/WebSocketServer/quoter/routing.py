from django.urls import path

from . import consumers

websocket_urlpatterns = [
    path('v1', consumers.QuoterConsumer.as_asgi()),
]