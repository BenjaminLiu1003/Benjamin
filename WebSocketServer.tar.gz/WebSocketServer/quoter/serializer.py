# from rest_framework.serializers import Serializer
# from rest_framework import serializers

# class ProgramSerializer(Serializer):
#   id = serializers.IntegerField()
#   name = serializers.CharField()
#   host = serializers.CharField()
#   pid = serializers.IntegerField()

from rest_framework import serializers
from .models import *


class ProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = "__all__"


class HostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Host
        fields = "__all__"


class ProgramSerializer(serializers.ModelSerializer):
    class Meta:
        model = Program
        fields = "__all__"


class LogSerializer(serializers.ModelSerializer):
    ctime = serializers.DateTimeField(
        format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)

    class Meta:
        model = Log
        fields = "__all__"


class ModuleSerializer(serializers.ModelSerializer):
    ctime = serializers.DateTimeField(
        format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)

    class Meta:
        model = Module
        fields = "__all__"

# class Component1Serializer(serializers.ModelSerializer):
#   ctime = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)

#   class Meta:
#     model = Component1
#     fields = "__all__"

# class Component2Serializer(serializers.ModelSerializer):
#   ctime = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)

#   class Meta:
#     model = Component2
#     fields = "__all__"

# class Component3Serializer(serializers.ModelSerializer):
#   ctime = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", required=False, read_only=True)

#   class Meta:
#     model = Component3
#     fields = "__all__"
