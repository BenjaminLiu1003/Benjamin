#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys
import requests
import time

def listen():
  cnt = 10
  while cnt:
    try:
      requests.get("http://localhost:6919/listen",)
    except Exception:
      cnt -= 1
      time.sleep(1)
    else:
      break

def main():
    """Run administrative tasks."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'WebSocketServer.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc

    import threading
    # from quoter.tasks import listen
    threading.Thread(target=listen, daemon=True).start()
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
