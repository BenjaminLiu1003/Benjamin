from rest_framework import serializers
from .models import *
from quoter.serializer import *


class SettingsSerializer(serializers.ModelSerializer):
    hosts = HostSerializer(many=True)
    projects = ProjectSerializer(many=True)

    class Meta:
        model = Settings
        fields = "__all__"
